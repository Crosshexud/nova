"""Окошко таймера NOVA: поверх всех окон, в правом нижнем углу, со звуком будильника.
Запуск: pythonw nova_alarm.pyw "Заголовок" "Текст". Код выхода 5 — «Ещё 5 минут», 0 — «Готово»."""

import os
import sys
import tkinter as tk
import winsound

TITLE = sys.argv[1] if len(sys.argv) > 1 else "Таймер"
TEXT = sys.argv[2] if len(sys.argv) > 2 else "Время вышло!"
SOUND = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Media", "Alarm01.wav")

BG, CARD, FG, MUTED, ACCENT = "#0d0b16", "#17132a", "#f1eeff", "#a9a3c4", "#7c3aed"
result = {"code": 0}


def play():
    try:
        if os.path.exists(SOUND):
            winsound.PlaySound(SOUND, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
        else:
            winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS | winsound.SND_ASYNC)
    except RuntimeError:
        pass


def stop_sound():
    try:
        winsound.PlaySound(None, 0)
    except RuntimeError:
        pass


def close(code):
    result["code"] = code
    stop_sound()
    root.destroy()


root = tk.Tk()
root.title("NOVA — " + TITLE)
root.overrideredirect(True)
root.attributes("-topmost", True)
root.configure(bg=ACCENT)  # рамка цвета NOVA

W, H = 380, 168
x = root.winfo_screenwidth() - W - 24
y = root.winfo_screenheight() - H - 72
root.geometry(f"{W}x{H}+{x}+{y}")

card = tk.Frame(root, bg=CARD, padx=18, pady=14)
card.place(x=1, y=1, width=W - 2, height=H - 2)

head = tk.Frame(card, bg=CARD)
head.pack(fill="x")
tk.Label(head, text="✦ NOVA", bg=CARD, fg="#c4b5fd", font=("Segoe UI Semibold", 10)).pack(side="left")
tk.Label(head, text="⏰ " + TITLE, bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(side="right")

tk.Label(card, text=TEXT, bg=CARD, fg=FG, font=("Segoe UI Semibold", 14), wraplength=W - 50,
         justify="left", anchor="w").pack(fill="x", pady=(10, 12))

btns = tk.Frame(card, bg=CARD)
btns.pack(fill="x", side="bottom")


def button(text, cmd, main=False):
    b = tk.Label(btns, text=text, bg=ACCENT if main else "#2a2342", fg="white", font=("Segoe UI Semibold", 10),
                 padx=16, pady=6, cursor="hand2")
    b.bind("<Button-1>", lambda e: cmd())
    b.bind("<Enter>", lambda e: b.configure(bg="#8b5cf6" if main else "#3a3158"))
    b.bind("<Leave>", lambda e: b.configure(bg=ACCENT if main else "#2a2342"))
    return b


button("Готово", lambda: close(0), main=True).pack(side="right")
button("Ещё 5 минут", lambda: close(5)).pack(side="right", padx=(0, 8))

root.bind("<Escape>", lambda e: close(0))
root.bind("<Return>", lambda e: close(0))
root.after(60_000, stop_sound)        # звенит не дольше минуты
root.after(10 * 60_000, lambda: close(0))  # само закроется через 10 минут
root.after(50, lambda: (root.lift(), root.focus_force()))
if os.environ.get("NOVA_ALARM_CLOSE"):  # для проверок: закрыться самому через N секунд
    root.after(int(float(os.environ["NOVA_ALARM_CLOSE"]) * 1000), lambda: close(0))
if os.environ.get("NOVA_ALARM_SILENT") != "1":  # для проверок — без звука
    play()
root.mainloop()
stop_sound()
sys.exit(result["code"])
