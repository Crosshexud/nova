"""NOVA — управление компьютером: программы, окна, громкость, папки, питание, скриншот экрана.

Безопасное (открыть программу или папку, громкость, список окон, блокировка) делается сразу.
Опасное (закрыть программу, сон, перезагрузка, выключение) — нет: инструмент только готовит действие,
под ответом NOVA появляется кнопка, и всё случится, когда пользователь её нажмёт (confirm()).
Без сторонних библиотек: только ctypes и встроенный PowerShell.
"""

import ctypes
import ctypes.wintypes as wt
import difflib
import json
import os
import re
import subprocess
import threading
import time
import uuid

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)


def log(text):  # nova_core подставит сюда свой журнал ошибок
    pass


def _powershell(script, timeout=25):
    """Выполнить PowerShell без окна и вернуть его вывод (UTF-8)."""
    r = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
         "[Console]::OutputEncoding = [Text.Encoding]::UTF8; " + script],
        capture_output=True, timeout=timeout, creationflags=CREATE_NO_WINDOW)
    return r.stdout.decode("utf-8", "replace")


# =========================
# Кнопки подтверждения
# =========================

_pending = {}   # номер → {"label", "run", "at"}
_fresh = []     # кнопки, приготовленные во время текущего ответа
ACTION_TTL = 15 * 60


def begin_answer():
    """Начался новый ответ — кнопки из прошлого ответа сюда больше не попадают."""
    _fresh.clear()


def take_fresh():
    """Кнопки, которые надо показать под этим ответом: [{"id", "label", "danger"}]."""
    out = list(_fresh)
    _fresh.clear()
    return out


def _ask(label, run, danger=False):
    for a in _fresh:  # модель дважды попросила одно и то же — кнопка одна
        if a["label"] == label:
            return a["id"]
    aid = uuid.uuid4().hex[:12]
    _pending[aid] = {"label": label, "run": run, "at": time.time()}
    _fresh.append({"id": aid, "label": label, "danger": danger})
    return aid


def confirm(aid, yes):
    """Пользователь нажал кнопку. Возвращает (получилось ли, текст для окна)."""
    for k in [k for k, v in _pending.items() if time.time() - v["at"] > ACTION_TTL]:
        _pending.pop(k, None)
    a = _pending.pop(str(aid), None)
    if not a:
        return False, "Кнопка устарела — попроси NOVA ещё раз."
    if not yes:
        return True, "Отменено."
    try:
        return True, a["run"]()
    except Exception as e:
        log(f"pc action «{a['label']}»: {e!r}")
        return False, f"Не получилось: {e}"


# =========================
# Названия: «дискорд» → Discord
# =========================

ALIASES = {
    "роблокс": "roblox", "роблокс студио": "roblox studio", "роблокс студия": "roblox studio",
    "дискорд": "discord", "дс": "discord", "стим": "steam", "крита": "krita",
    "телеграм": "telegram", "телеграмм": "telegram", "телега": "telegram", "тг": "telegram",
    "хром": "google chrome", "гугл хром": "google chrome", "эдж": "microsoft edge", "едж": "microsoft edge",
    "блокнот": "notepad", "калькулятор": "calculator", "проводник": "проводник", "пейнт": "paint", "паинт": "paint",
    "майнкрафт": "minecraft launcher", "эпик": "epic games launcher", "эпик геймс": "epic games launcher",
    "обс": "obs studio", "блендер": "blender", "годот": "godot", "спотифай": "spotify",
    "ворд": "word", "эксель": "excel", "фотошоп": "photoshop", "вс код": "visual studio code",
    "вскод": "visual studio code", "визуал студио код": "visual studio code", "ватсап": "whatsapp",
    "вотсап": "whatsapp", "зум": "zoom", "тимс": "teams", "скайп": "skype", "яндекс": "yandex",
    "яндекс браузер": "yandex", "опера": "opera", "фаерфокс": "firefox", "файрфокс": "firefox",
    "мозилла": "firefox", "вк": "vk", "кап кат": "capcut", "капкат": "capcut", "ютуб музыка": "youtube music",
    "настройки": "settings", "параметры": "settings", "параметры windows": "settings",
}
# Стандартное Windows, которого может не быть в «Пуске» под понятным именем
BUILTIN = {
    "settings": ("Параметры Windows", "ms-settings:"),
    "диспетчер задач": ("Диспетчер задач", "taskmgr.exe"),
    "task manager": ("Диспетчер задач", "taskmgr.exe"),
    "панель управления": ("Панель управления", "control.exe"),
    "этот компьютер": ("Этот компьютер", "shell:MyComputerFolder"),
    "мой компьютер": ("Этот компьютер", "shell:MyComputerFolder"),
    "корзина": ("Корзина", "shell:RecycleBinFolder"),
}
_TR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
               ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s",
                "t", "u", "f", "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))
FILLER = re.compile(r"^(?:мне\s+|пожалуйста\s+|пж\s+|плиз\s+)*(?:программу|приложение|прогу|игру|окно)?\s*")
SKIP_APP = re.compile(r"uninstall|удал|readme|help|справк|support|documentation|документац|website|"
                      r"release notes|manual|руководств|license|лиценз", re.I)


def _norm(s):
    s = str(s or "").lower().replace("ё", "е")
    s = re.sub(r"[^\w\s+.-]", " ", s)
    return " ".join(s.replace("_", " ").split())


def _variants(query):
    q = _norm(query)
    q = FILLER.sub("", q).strip(" .,!?") or q
    out = [q]
    if q in ALIASES:
        out.insert(0, ALIASES[q])
    tr = "".join(_TR.get(ch, ch) for ch in q)
    if tr != q:
        out.append(tr)
    return [v for i, v in enumerate(out) if v and v not in out[:i]]


def _score(variant, name):
    if name == variant:
        return 1.0
    if name.startswith(variant):
        return 0.93 - 0.002 * len(name)  # короче — ближе к тому, что просили
    if len(variant) >= 3 and (" " + variant) in (" " + name):
        return 0.86 - 0.002 * len(name)
    return difflib.SequenceMatcher(None, variant, name).ratio() * 0.9


# =========================
# Программы: меню «Пуск» и ярлыки на рабочем столе
# =========================

class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
                ("Data4", ctypes.c_ubyte * 8)]


def _guid(text):
    g = GUID()
    ctypes.windll.ole32.CLSIDFromString(ctypes.c_wchar_p("{" + text + "}"), ctypes.byref(g))
    return g


KNOWN = {  # папка → идентификатор Windows (у кого «Рабочий стол» в OneDrive — Windows сама скажет, где он)
    "desktop": "B4BFCC3A-DB2C-424C-B029-7FE99A87C641", "documents": "FDD39AD0-238F-46AF-ADB4-6C85480369C7",
    "downloads": "374DE290-123F-4565-9164-39C4925E467B", "pictures": "33E28130-4E1E-4676-835A-98395C3BC3BB",
    "music": "4BD8D571-6D19-48D3-BE97-422220080E43", "videos": "18989B1D-99B5-455B-841C-AB7C74E4DDFC",
    "public_desktop": "C4AA340D-F20F-4863-AFEF-F87EF2E6BA25",
}
FOLDER_WORDS = {
    "загрузки": "downloads", "закачки": "downloads", "downloads": "downloads",
    "рабочий стол": "desktop", "рабочем столе": "desktop", "desktop": "desktop",
    "документы": "documents", "мои документы": "documents", "documents": "documents",
    "изображения": "pictures", "картинки": "pictures", "фото": "pictures", "фотографии": "pictures",
    "pictures": "pictures", "музыка": "music", "music": "music", "видео": "videos", "videos": "videos",
}


def known_folder(key):
    try:
        path = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(_guid(KNOWN[key])), 0, None,
                                                      ctypes.byref(path)) == 0:
            result = path.value
            ctypes.windll.ole32.CoTaskMemFree(path)
            if result and os.path.isdir(result):
                return result
    except Exception as e:
        log(f"known_folder {key}: {e!r}")
    return None


_apps = {"at": 0.0, "list": []}
_apps_lock = threading.Lock()


def start_apps():
    """Программы из меню «Пуск» (как их видит Windows) и ярлыки с рабочего стола. Кэш на 10 минут."""
    with _apps_lock:
        if _apps["list"] and time.time() - _apps["at"] < 600:
            return _apps["list"]
        apps = []
        try:
            data = json.loads(_powershell("Get-StartApps | Select-Object Name, AppID | ConvertTo-Json -Compress") or "[]")
            for a in [data] if isinstance(data, dict) else data:
                name, aid = a.get("Name"), str(a.get("AppID") or "")
                if name and aid and not SKIP_APP.search(name) and not aid.lower().startswith(("http:", "https:")):
                    apps.append({"name": name, "id": aid})
        except Exception as e:
            log(f"start_apps: {e!r}")
        for key in ("desktop", "public_desktop"):
            folder = known_folder(key)
            if not folder:
                continue
            for f in os.listdir(folder):
                stem, ext = os.path.splitext(f)
                if ext.lower() in (".lnk", ".url") and not SKIP_APP.search(stem):
                    apps.append({"name": stem, "path": os.path.join(folder, f)})
        _apps.update(at=time.time(), list=apps)
        return apps


def find_app(query, strict=False):
    """(программа, варианты): программа — если нашлась одна; варианты — если подходят несколько."""
    vs = _variants(query)
    for v in vs:
        if v in BUILTIN:
            name, target = BUILTIN[v]
            return {"name": name, "builtin": target}, []
    scored = []
    for app in start_apps():
        n = _norm(app["name"])
        scored.append((max(_score(v, n) for v in vs), app))
    scored.sort(key=lambda x: -x[0])
    good = [(s, a) for s, a in scored if s >= (0.9 if strict else 0.76)]
    if not good:
        return None, []
    best, app = good[0]
    rivals = [a for s, a in good[1:] if best - s < 0.012 and _norm(a["name"]) != _norm(app["name"])]
    if rivals:
        return None, [app["name"]] + [a["name"] for a in rivals[:4]]
    return app, []


def _launch(app):
    if app.get("builtin"):
        target = app["builtin"]
        if target.startswith("shell:"):
            subprocess.Popen(["explorer.exe", target], creationflags=CREATE_NO_WINDOW)
        else:
            os.startfile(target)
    elif app.get("path"):
        os.startfile(app["path"])
    elif "://" in app["id"]:
        os.startfile(app["id"])  # игры Steam: steam://rungameid/…
    else:
        subprocess.Popen(["explorer.exe", "shell:AppsFolder\\" + app["id"]], creationflags=CREATE_NO_WINDOW)


# =========================
# Окна
# =========================

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
user32.EnumWindows.argtypes = [WNDENUMPROC, wt.LPARAM]
user32.IsWindowVisible.argtypes = [wt.HWND]
user32.IsWindow.argtypes = [wt.HWND]
user32.GetWindow.argtypes = [wt.HWND, wt.UINT]
user32.GetWindow.restype = wt.HWND
user32.GetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int]
user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.GetWindowTextLengthW.argtypes = [wt.HWND]
user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
user32.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
user32.SetForegroundWindow.argtypes = [wt.HWND]
user32.IsIconic.argtypes = [wt.HWND]
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD)]
kernel32.CloseHandle.argtypes = [wt.HANDLE]
try:
    dwmapi = ctypes.WinDLL("dwmapi")
    dwmapi.DwmGetWindowAttribute.argtypes = [wt.HWND, wt.DWORD, ctypes.c_void_p, wt.DWORD]
except OSError:
    dwmapi = None


def _exe_of(pid):
    h = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return ""
    try:
        buf, size = ctypes.create_unicode_buffer(1024), wt.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return os.path.basename(buf.value)
        return ""
    finally:
        kernel32.CloseHandle(h)


def open_windows():
    """Видимые окна программ (как на панели задач): [{"hwnd", "title", "exe", "pid"}]."""
    found = []

    def cb(hwnd, _):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.GetWindow(hwnd, 4):  # 4 = владелец (диалоги)
                return True
            if user32.GetWindowLongPtrW(hwnd, -20) & 0x80:  # служебные окна-панели
                return True
            if dwmapi:
                cloaked = ctypes.c_int(0)
                dwmapi.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(cloaked), 4)
                if cloaked.value:  # спрятанные окна (свёрнутые в фон приложения Магазина)
                    return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value.strip()
            if not title or title == "Program Manager":
                return True
            pid = wt.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            found.append({"hwnd": hwnd, "title": title, "exe": _exe_of(pid.value), "pid": pid.value})
        except Exception:
            pass
        return True

    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return found


def _is_nova(w):
    return w["exe"].lower() == "msedge.exe" and w["title"] == "NOVA" or w["pid"] == os.getpid()


def _pretty(w):
    """Короткое имя программы для кнопки: «jh.jpg * - Krita» → «Krita», RobloxPlayerBeta.exe → «Roblox»."""
    t = w["title"]
    for sep in (" - ", " — ", " | "):
        if sep in t:
            t = t.split(sep)[-1].strip()
    if 2 <= len(t) <= 32:
        return t
    stem = os.path.splitext(w["exe"])[0]
    return re.sub(r"(?i)(player)?beta$|\.exe$", "", stem) or stem


def _match_windows(query):
    """Окна, подходящие под название, по программам: [(exe, [окна], оценка)], лучшие первыми."""
    vs = [v for v in _variants(query) if len(v) >= 2]
    groups = {}
    for w in open_windows():
        if _is_nova(w):
            continue
        stem = _norm(os.path.splitext(w["exe"])[0])
        title = _norm(w["title"])
        best = 0.0
        for v in vs:
            vc = v.replace(" ", "")
            if vc and (vc in stem.replace(" ", "") or (len(stem) >= 4 and stem in vc)):
                best = max(best, 1.0)
            elif len(v) >= 3 and v in title:
                best = max(best, 0.9)
            else:
                best = max(best, difflib.SequenceMatcher(None, vc, stem).ratio() * 0.85)
        if best >= 0.75:
            g = groups.setdefault(w["exe"].lower(), [w["exe"], [], 0.0])
            g[1].append(w)
            g[2] = max(g[2], best)
    return sorted((tuple(g) for g in groups.values()), key=lambda g: -g[2])


def _close(wins, name):
    pids = {w["pid"] for w in wins}
    for w in wins:
        if user32.IsWindow(w["hwnd"]):
            user32.PostMessageW(w["hwnd"], 0x0010, 0, 0)  # WM_CLOSE — как крестик: программа может спросить «сохранить?»
    for _ in range(12):
        time.sleep(0.25)
        if not any(w["pid"] in pids for w in open_windows()):
            return f"Закрыла {name}."
    return (f"Я попросила {name} закрыться, но окно ещё открыто — может, программа спрашивает, "
            "сохранить ли изменения. Загляни в неё.")


# =========================
# Громкость (Windows Core Audio через ctypes)
# =========================

def _com(obj, index, *argtypes):
    vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
    fn = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, *argtypes)(vtbl[index])
    return lambda *args: fn(obj, *args)


def _with_volume(work):
    ole32 = ctypes.windll.ole32
    inited = ole32.CoInitializeEx(None, 0) in (0, 1)
    enum, dev, vol = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
    try:
        hr = ole32.CoCreateInstance(ctypes.byref(_guid("BCDE0395-E52F-467C-8E3D-C4579291692E")), None, 23,
                                    ctypes.byref(_guid("A95664D2-9614-4F35-A746-DE8DB63617E6")), ctypes.byref(enum))
        if hr != 0:
            raise OSError(f"звук недоступен (код {hr & 0xFFFFFFFF:#x})")
        # IMMDeviceEnumerator::GetDefaultAudioEndpoint(вывод звука, мультимедиа)
        _com(enum, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))(0, 1, ctypes.byref(dev))
        # IMMDevice::Activate(IAudioEndpointVolume)
        _com(dev, 3, ctypes.POINTER(GUID), ctypes.c_ulong, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p))(
            ctypes.byref(_guid("5CDF2C82-841E-4546-9722-0CF74078229A")), 23, None, ctypes.byref(vol))
        return work(vol)
    finally:
        for p in (vol, dev, enum):
            if p.value:
                _com(p, 2)()  # Release
        if inited:
            ole32.CoUninitialize()


def _vol_get(v):
    level, mute = ctypes.c_float(), ctypes.c_int()
    _com(v, 9, ctypes.POINTER(ctypes.c_float))(ctypes.byref(level))  # GetMasterVolumeLevelScalar
    _com(v, 15, ctypes.POINTER(ctypes.c_int))(ctypes.byref(mute))    # GetMute
    return round(level.value * 100), bool(mute.value)


def _vol_set_level(v, pct):
    _com(v, 7, ctypes.c_float, ctypes.c_void_p)(max(0.0, min(1.0, pct / 100)), None)  # SetMasterVolumeLevelScalar


def _vol_set_mute(v, on):
    _com(v, 14, ctypes.c_int, ctypes.c_void_p)(1 if on else 0, None)  # SetMute


# =========================
# Скриншот экрана
# =========================

SCREEN_RE = re.compile(
    r"(посмотри|посмотреть|глянь|взгляни|смотри|оцени|проверь|видишь|что\s+видишь|что\s+там)\W+(\w+\W+){0,3}?"
    r"(на\s+)?(мо[йёе]м?\s+|у\s+меня\s+(на\s+)?)?(экран|скрин|монитор)"
    r"|(что|чё|че|чего)\s+(\w+\s+){0,3}на\s+(мо[её]м\s+)?экране"
    r"|(сделай|сними|кинь|сфоткай|глянь)\s+(\w+\s+){0,2}(скрин|скриншот|снимок\s+экрана)", re.I)


def wants_screenshot(text):
    return bool(SCREEN_RE.search(text or ""))


gdi32 = ctypes.WinDLL("gdi32")
user32.GetDC.argtypes = [wt.HWND]
user32.GetDC.restype = wt.HDC
user32.ReleaseDC.argtypes = [wt.HWND, wt.HDC]
gdi32.CreateCompatibleDC.argtypes = [wt.HDC]
gdi32.CreateCompatibleDC.restype = wt.HDC
gdi32.CreateCompatibleBitmap.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int]
gdi32.CreateCompatibleBitmap.restype = wt.HBITMAP
gdi32.SelectObject.argtypes = [wt.HDC, wt.HGDIOBJ]
gdi32.SelectObject.restype = wt.HGDIOBJ
gdi32.SetStretchBltMode.argtypes = [wt.HDC, ctypes.c_int]
gdi32.SetBrushOrgEx.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
gdi32.StretchBlt.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                             wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.DWORD]
gdi32.GetDIBits.argtypes = [wt.HDC, wt.HBITMAP, wt.UINT, wt.UINT, ctypes.c_void_p, ctypes.c_void_p, wt.UINT]
gdi32.DeleteObject.argtypes = [wt.HGDIOBJ]
gdi32.DeleteDC.argtypes = [wt.HDC]


class _BMIH(ctypes.Structure):
    _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG), ("biPlanes", wt.WORD),
                ("biBitCount", wt.WORD), ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                ("biClrImportant", wt.DWORD)]


def _grab(max_w=1920):
    """Весь экран (все мониторы) средствами Windows (GDI): (ширина, высота, байты RGB)."""
    try:
        user32.SetProcessDPIAware()  # иначе при масштабе 125% Windows отдаст уменьшенную копию
    except Exception:
        pass
    x, y = user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)  # левый верхний угол всех мониторов
    w, h = user32.GetSystemMetrics(78), user32.GetSystemMetrics(79)  # их общий размер
    k = min(1.0, max_w / w)
    tw, th = max(1, int(w * k)), max(1, int(h * k))
    screen = user32.GetDC(None)
    mem = gdi32.CreateCompatibleDC(screen)
    bmp = gdi32.CreateCompatibleBitmap(screen, tw, th)
    old = gdi32.SelectObject(mem, bmp)
    try:
        gdi32.SetStretchBltMode(mem, 4)  # HALFTONE — уменьшать аккуратно
        gdi32.SetBrushOrgEx(mem, 0, 0, None)
        if not gdi32.StretchBlt(mem, 0, 0, tw, th, screen, x, y, w, h, 0x00CC0020 | 0x40000000):  # SRCCOPY | CAPTUREBLT
            raise OSError("Windows не дала снять экран")
        bi = _BMIH(ctypes.sizeof(_BMIH), tw, -th, 1, 32, 0, 0, 0, 0, 0, 0)  # минус — строки сверху вниз
        buf = ctypes.create_string_buffer(tw * th * 4)
        if not gdi32.GetDIBits(mem, bmp, 0, th, buf, ctypes.byref(bi), 0):
            raise OSError("не получилось прочитать снимок")
    finally:
        gdi32.SelectObject(mem, old)
        gdi32.DeleteObject(bmp)
        gdi32.DeleteDC(mem)
        user32.ReleaseDC(None, screen)
    raw = bytearray(buf.raw)
    raw[0::4], raw[2::4] = raw[2::4], raw[0::4]  # BGRA → RGBA
    del raw[3::4]                                # → RGB
    return tw, th, raw


def _encode(w, h, rgb):
    """(байты, mime): JPEG, если есть Pillow, иначе PNG стандартной библиотекой."""
    try:
        import io
        from PIL import Image
        out = io.BytesIO()
        Image.frombytes("RGB", (w, h), bytes(rgb)).save(out, "JPEG", quality=85)
        return out.getvalue(), "image/jpeg"
    except ImportError:
        pass
    import struct
    import zlib
    stride = w * 3
    rows = b"".join(b"\x00" + bytes(rgb[i * stride:(i + 1) * stride]) for i in range(h))

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)

    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(rows, 6)) + chunk(b"IEND", b""))
    return png, "image/png"


def screenshot():
    """Снимок всего экрана: (байты, mime). Окно NOVA на это время сворачивается, чтобы не закрывать экран."""
    nova = [w for w in open_windows() if _is_nova(w) and not user32.IsIconic(w["hwnd"])]
    try:
        for w in nova:
            user32.ShowWindow(w["hwnd"], 6)  # свернуть
        if nova:
            time.sleep(0.45)  # дождаться, пока окно уедет
        return _encode(*_grab())
    finally:
        for w in nova:
            user32.ShowWindow(w["hwnd"], 9)  # вернуть
            user32.SetForegroundWindow(w["hwnd"])


# =========================
# Инструменты для нейросетей
# =========================

RISKY_EXT = {".exe", ".bat", ".cmd", ".com", ".ps1", ".psm1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".wsh",
             ".msi", ".msp", ".scr", ".reg", ".hta", ".pif", ".cpl", ".jar", ".lnk", ".url", ".appref-ms", ".py",
             ".pyw", ".inf", ".sys", ".dll"}


def open_app(name: str) -> dict:
    """Открыть (запустить) программу или игру на компьютере пользователя — например Roblox, Discord, Steam, Krita,
    Telegram, браузер, Блокнот, Калькулятор, Проводник, Параметры Windows, Диспетчер задач. Ищет в меню «Пуск»
    и среди ярлыков на рабочем столе.

    Args:
        name: название программы так, как его назвал пользователь (например, «дискорд» или «Roblox Studio»)
    """
    app, options = find_app(name)
    if options:
        return {"error": "Подходят несколько программ — спроси пользователя, какую открыть.", "options": options}
    if not app:
        return {"error": f"Не нашла программу «{name}» в меню «Пуск» и на рабочем столе — скорее всего, "
                         "она не установлена. Скажи об этом пользователю."}
    _launch(app)
    return {"ok": True, "opened": app["name"]}


def close_app(name: str) -> dict:
    """Закрыть открытую программу или игру (например Roblox, Krita, Discord, Блокнот). Закрывает не сразу:
    под твоим ответом появится кнопка, и программа закроется, когда пользователь её нажмёт, — скажи ему об этом
    коротко.

    Args:
        name: название программы или окна (например, «роблокс» или «Krita»)
    """
    groups = _match_windows(name)
    if not groups:
        now = sorted({_pretty(w) for w in open_windows() if not _is_nova(w)})
        return {"error": f"Не вижу открытой программы «{name}».", "open_now": now[:25]}
    top = groups[0][2]
    same = [g for g in groups if top - g[2] < 0.05]
    if len(same) > 1:
        return {"error": "Подходят несколько программ — спроси пользователя, какую закрыть.",
                "options": [_pretty(g[1][0]) for g in same[:5]]}
    exe, wins, _ = groups[0]
    pretty = _pretty(wins[0])
    label = f"Закрыть {pretty}"
    _ask(label, lambda: _close(wins, pretty), danger=True)
    return {"ok": True, "waiting_for_user": f"Под ответом кнопка «{label}». Закроется, когда пользователь её нажмёт.",
            "windows": [w["title"] for w in wins][:5]}


def list_windows(name: str) -> dict:
    """Какие программы и окна сейчас открыты на компьютере пользователя (например, «что у меня открыто?»,
    «открыт ли Roblox?»).

    Args:
        name: часть названия, чтобы проверить одну программу (пустая строка — показать все)
    """
    wins = [w for w in open_windows() if not _is_nova(w)]
    if (name or "").strip():
        hits = {g[0].lower() for g in _match_windows(name)}
        wins = [w for w in wins if w["exe"].lower() in hits]
        if not wins:
            return {"open": False, "note": f"Программа «{name}» сейчас не открыта."}
    return {"windows": [{"program": _pretty(w), "title": w["title"][:80]} for w in wins[:30]]}


def set_volume(level: str) -> dict:
    """Громкость звука на компьютере: поставить, сделать громче или тише, выключить или включить звук, узнать текущую.

    Args:
        level: число от 0 до 100 — поставить такую громкость; «+10» или «-10» — громче или тише на столько; «mute» — выключить звук; «unmute» — включить звук; «?» — узнать текущую
    """
    s = str(level or "").strip().lower().replace("%", "")

    def work(v):
        before, muted = _vol_get(v)
        if s in ("mute", "off", "выкл", "выключить", "0 mute"):
            _vol_set_mute(v, True)
        elif s in ("unmute", "on", "вкл", "включить"):
            _vol_set_mute(v, False)
        elif re.fullmatch(r"[+-]\s*\d{1,3}", s):
            _vol_set_level(v, before + int(s.replace(" ", "")))
            if muted:
                _vol_set_mute(v, False)
        elif re.fullmatch(r"\d{1,3}", s):
            _vol_set_level(v, int(s))
            if muted and int(s) > 0:
                _vol_set_mute(v, False)
        elif s not in ("?", "", "get", "узнать"):
            return {"error": "Не поняла, какую громкость поставить: нужно число 0–100, «+10», «-10», «mute» или «unmute»."}
        after, muted_now = _vol_get(v)
        return {"ok": True, "volume": after, "muted": muted_now, "was": before}

    return _with_volume(work)


def open_folder(place: str) -> dict:
    """Открыть папку в Проводнике или файл в программе по умолчанию: «Загрузки», «Рабочий стол», «Документы»,
    «Изображения», «Музыка», «Видео», «Этот компьютер», «Корзина» или полный путь. Программы так не запускаются —
    для них open_app.

    Args:
        place: название папки (например, «загрузки») или полный путь к папке или файлу
    """
    q = _norm(place).strip(" .")
    key = FOLDER_WORDS.get(q) or FOLDER_WORDS.get(re.sub(r"^(папк[ауи]|в)\s+", "", q))
    if key:
        path = known_folder(key)
        if path:
            os.startfile(path)
            return {"ok": True, "opened": path}
    for v in _variants(place):
        if v in BUILTIN and BUILTIN[v][1].startswith("shell:"):
            _launch({"builtin": BUILTIN[v][1]})
            return {"ok": True, "opened": BUILTIN[v][0]}
    path = os.path.expandvars(os.path.expanduser(str(place or "").strip().strip('"«»')))
    if not path or not os.path.exists(path):
        return {"error": f"Не нашла папку или файл «{place}». Нужен полный путь, например C:\\Users\\…\\Pictures."}
    if os.path.isfile(path) and os.path.splitext(path)[1].lower() in RISKY_EXT:
        return {"error": "Это программа или скрипт — такие файлы NOVA не запускает. Можно открыть папку, где он лежит."}
    if os.path.isfile(path):
        os.startfile(path)
    else:
        subprocess.Popen(["explorer.exe", os.path.normpath(path)], creationflags=CREATE_NO_WINDOW)
    return {"ok": True, "opened": path}


def _shutdown(flag, what):
    subprocess.run(["shutdown", flag, "/t", "20", "/c",
                    f"NOVA: компьютер {what} через 20 секунд. Чтобы отменить — скажи NOVA «отмени выключение»."],
                   creationflags=CREATE_NO_WINDOW, timeout=10)
    return f"Компьютер {what} через 20 секунд. Чтобы отменить — скажи «отмени выключение»."


def _sleep():
    threading.Timer(1.5, lambda: ctypes.windll.powrprof.SetSuspendState(0, 0, 0)).start()
    return "Усыпляю компьютер."


def power(action: str) -> dict:
    """Заблокировать, усыпить, перезагрузить или выключить компьютер, или отменить запланированное выключение.
    Блокировка и отмена — сразу; сон, перезагрузка и выключение — только после кнопки под твоим ответом
    (скажи пользователю её нажать).

    Args:
        action: lock — заблокировать; sleep — сон; restart — перезагрузить; shutdown — выключить; cancel — отменить выключение
    """
    a = str(action or "").strip().lower()
    a = {"заблокировать": "lock", "блокировка": "lock", "сон": "sleep", "спать": "sleep", "перезагрузка": "restart",
         "перезагрузить": "restart", "reboot": "restart", "выключить": "shutdown", "выключение": "shutdown",
         "off": "shutdown", "отмена": "cancel", "отменить": "cancel", "abort": "cancel"}.get(a, a)
    if a == "lock":
        ctypes.windll.user32.LockWorkStation()
        return {"ok": True, "done": "Компьютер заблокирован."}
    if a == "cancel":
        r = subprocess.run(["shutdown", "/a"], capture_output=True, creationflags=CREATE_NO_WINDOW, timeout=10)
        return {"ok": True, "done": "Выключение отменено."} if r.returncode == 0 else \
            {"ok": True, "done": "Выключение и не было запланировано."}
    if a == "sleep":
        _ask("Усыпить компьютер", _sleep, danger=True)
    elif a == "restart":
        _ask("Перезагрузить компьютер", lambda: _shutdown("/r", "перезагрузится"), danger=True)
    elif a == "shutdown":
        _ask("Выключить компьютер", lambda: _shutdown("/s", "выключится"), danger=True)
    else:
        return {"error": "Нужно одно из: lock, sleep, restart, shutdown, cancel."}
    return {"ok": True, "waiting_for_user": "Под ответом кнопка подтверждения — сработает, когда пользователь её нажмёт."}


TOOLS = [open_app, close_app, list_windows, set_volume, open_folder, power]


# =========================
# Быстрые команды без нейросети («открой дискорд», «закрой роблокс», «выключи звук»)
# =========================

def quick_command(text):
    """Текст ответа, если это понятная команда для компьютера, иначе None (тогда спросим нейросеть)."""
    t = _norm(text).strip(" .!")
    if t in ("выключи звук", "убери звук", "без звука", "замьють", "mute"):
        r = set_volume("mute")
        return "Звук выключен. 🔇" if r.get("ok") else None
    if t in ("включи звук", "верни звук", "unmute"):
        r = set_volume("unmute")
        return f"Звук включён, громкость {r['volume']}%. 🔊" if r.get("ok") else None
    m = re.fullmatch(r"(?:поставь\s+)?громкость\s+(?:на\s+)?(\d{1,3})", t)
    if m:
        r = set_volume(m.group(1))
        return f"Громкость {r['volume']}%." if r.get("ok") else None
    if t in ("заблокируй компьютер", "заблокируй комп", "заблокируй пк"):
        power("lock")
        return "Блокирую компьютер. 🔒"
    if t in ("отмени выключение", "отмени перезагрузку", "не выключай"):
        return power("cancel")["done"]
    m = re.fullmatch(r"(?:открой|запусти)\s+(.+)", t)
    if m:
        target = m.group(1)
        key = FOLDER_WORDS.get(target) or FOLDER_WORDS.get(re.sub(r"^(папк[ауи])\s+", "", target))
        if key:
            r = open_folder(target)
            return f"Открываю папку **{os.path.basename(r['opened']) or r['opened']}**." if r.get("ok") else None
        app, _ = find_app(target, strict=True)
        if app:
            _launch(app)
            return f"Открываю **{app['name']}**."
        return None
    m = re.fullmatch(r"закрой\s+(.+)", t)
    if m:
        groups = _match_windows(m.group(1))
        if groups and groups[0][2] >= 0.9 and (len(groups) == 1 or groups[0][2] - groups[1][2] >= 0.05):
            r = close_app(m.group(1))
            if r.get("ok"):
                return f"Закрыть **{_pretty(groups[0][1][0])}**? Нажми кнопку ниже — если там что-то не сохранено, программа сама спросит."
        return None
    return None
