"""
NOVA — ядро без интерфейса: Gemini, интернет-инструменты, вложения (картинки и файлы),
история чатов, настройки и команды.

Интерфейс (окно) — в nova.pyw и папке ui. Старая версия на tkinter — nova_classic.pyw.
"""

import html
import inspect
import io
import json
import os
import re
import subprocess
import threading
import time
import traceback
import uuid
import webbrowser
import zipfile
from datetime import datetime
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import quote, quote_plus, unquote, urlparse


# =========================
# НАСТРОЙКИ
# =========================

# Три модели NOVA — свои, от лёгкой к сильной:
#   Note     — лёгкая: маленькая нейросеть прямо на этом компьютере (Ollama). Без интернета, ключа и лимитов.
#   Chord    — средняя: побольше и поумнее, тоже на этом компьютере.
#   Symphony — сильная: Gemini от Google через интернет. Самая умная, видит картинки и PDF.
# У Symphony несколько моделей Google по порядку: если одну отключат, перегрузят или она зависнет,
# NOVA перейдёт на следующую. Второе значение — насколько модель «думает» перед ответом.
# ctx — сколько текста локальная модель держит в голове (больше — нужно больше видеопамяти).
MODES = {
    "note": {
        "title": "Note", "kind": "лёгкая модель", "hint": "Мгновенные ответы прямо на твоём компьютере",
        "engine": "ollama", "ctx": 16384,
        "models": [("qwen3:4b-instruct", None)],
    },
    "chord": {
        "title": "Chord", "kind": "средняя модель", "hint": "Умнее и подробнее, тоже на твоём компьютере",
        "engine": "ollama", "ctx": 8192,
        "models": [("qwen3:8b", None)],
    },
    "symphony": {
        "title": "Symphony", "kind": "сильная модель", "hint": "Самая умная, видит картинки и PDF. Нужен интернет",
        "engine": "gemini",
        "models": [
            ("gemini-3.5-flash", "LOW"),
            ("gemini-3.7-flash", "LOW"),
            ("gemini-flash-lite-latest", None),
        ],
    },
}
STRONG_MODE = "symphony"
DEFAULT_MODE = "symphony"  # работает у любого, у кого есть ключ Gemini; Ollama нужен не всем
OLD_MODES = {"fast": "note", "smart": "symphony"}  # прежние «Быстрая» и «Умная»

# Характер NOVA — выбирается в настройках.
PERSONAS = {
    "friendly": {
        "title": "Дружелюбная", "desc": "Тёплая, живая, по делу",
        "prompt": "Общайся дружелюбно и по-человечески, по делу; лёгкий юмор и эмодзи — к месту и в меру.",
    },
    "brief": {
        "title": "Краткая", "desc": "Только суть, без воды",
        "prompt": "Отвечай максимально коротко и по делу: без вступлений, повторов и лишних слов. "
                  "Подробности — только если попросят.",
    },
    "fun": {
        "title": "Весёлая", "desc": "Шутит и не даёт заскучать",
        "prompt": "Общайся весело и задорно, как близкий друг: шути, используй эмодзи, "
                  "но всегда оставайся полезной и точной.",
    },
    "teacher": {
        "title": "Учитель", "desc": "Объясняет просто и подробно",
        "prompt": "Объясняй как терпеливый хороший учитель: просто, по шагам, с примерами и аналогиями; "
                  "в конце коротко подытожь главное.",
    },
}

DEFAULT_SETTINGS = {
    "mode": "symphony",     # модель по умолчанию
    "name": "",             # как зовут пользователя
    "city": "",             # город для погоды по умолчанию
    "persona": "friendly",  # характер NOVA
    "custom": "",           # свои инструкции для NOVA
    "auto_speak": False,    # озвучивать ответы сразу
    "voice_send": False,    # голосовое сообщение отправлять сразу, без Enter
    "voice": "",            # имя голоса (пусто — выбрать самый естественный русский)
    "rate": 1.05,           # скорость озвучки
}

BASE_PROMPT = "Ты NOVA — персональный ИИ-ассистент. О себе говоришь в женском роде. Отвечай на языке пользователя."

FORMAT_PROMPT = (
    "Ответы показываются с Markdown-оформлением: используй его, когда это помогает читать — "
    "**жирный** для главного, списки, короткие заголовки ###, `код` и блоки ```кода``` с указанием языка, "
    "таблицы для сравнений. Короткие ответы не перегружай оформлением."
)

FILES_PROMPT = (
    "Пользователь может присылать картинки, скриншоты и файлы (код, тексты, PDF, документы). "
    "Внимательно изучай их содержимое. Если прислали несколько версий одного и того же (например, старую и новую), "
    "сравнивай их конкретно и по пунктам: что стало лучше, что хуже, что можно улучшить, и дай общую оценку."
)

INTERNET_PROMPT = (
    "У тебя есть доступ к интернету через инструменты: web_search, news_search, get_weather, "
    "get_exchange_rates и read_webpage. Обязательно пользуйся ими, когда вопрос касается того, что "
    "меняется со временем: новости, погода, курсы валют и криптовалют, цены, спорт, релизы, "
    "«кто сейчас…», события последних лет, а также когда тебя просят что-то найти или дают ссылку. "
    "Не выдумывай свежие факты и цифры — сначала проверь. Если описаний из поиска мало, открой "
    "самую подходящую страницу через read_webpage. Для погоды нужен город: если его не назвали "
    "и город пользователя неизвестен — спроси. "
    "Ссылки в текст ответа не вставляй — источники покажутся под ответом автоматически."
)

# Для маленьких моделей на компьютере — коротко и жёстко, иначе они «вспоминают» цифры вместо поиска.
LOCAL_TOOLS_PROMPT = (
    "У тебя есть инструменты для интернета. Правила, которые нельзя нарушать:\n"
    "• курс валют (доллар, евро, юань…) → вызови get_exchange_rates;\n"
    "• погода → get_weather;\n"
    "• новости, «что случилось» → news_search;\n"
    "• цены, криптовалюты, спорт, события, «кто сейчас», любые свежие факты → web_search;\n"
    "• дали ссылку → read_webpage.\n"
    "Никогда не называй по памяти курсы, цены, погоду, счёт матчей и другие свежие цифры — сначала вызови "
    "инструмент и отвечай по его результату. Если инструмент не помог, честно скажи, что узнать не получилось. "
    "Ссылки в ответ не вставляй — источники покажутся под ответом сами."
)

WEEKDAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]

MAX_HISTORY = 40          # сколько последних реплик NOVA помнит в одном чате
KEEP_ATTACHMENTS = 3      # вложения скольких последних сообщений NOVA «держит перед глазами» целиком
REQUEST_TIMEOUT_SEC = 20  # ответ идёт кусочками; 20 секунд тишины — модель зависла, пора на следующую

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = APP_DIR  # можно подменить (например, для проверок) через set_data_dir
LOG_FILE = os.path.join(APP_DIR, "nova_errors.log")


def set_data_dir(path):
    global DATA_DIR
    DATA_DIR = path


def settings_file():
    return os.path.join(DATA_DIR, "nova_settings.json")


def chats_dir():
    return os.path.join(DATA_DIR, "chats")


def files_dir():
    return os.path.join(chats_dir(), "files")


def clean_settings(data):
    """Проверить настройки: всё лишнее и неправильное заменяется значениями по умолчанию."""
    s = dict(DEFAULT_SETTINGS)
    if not isinstance(data, dict):
        return s
    if data.get("mode") in MODES:
        s["mode"] = data["mode"]
    elif data.get("mode") in OLD_MODES:
        s["mode"] = OLD_MODES[data["mode"]]
    if data.get("persona") in PERSONAS:
        s["persona"] = data["persona"]
    for key, limit in (("name", 40), ("city", 60), ("voice", 120), ("custom", 1500)):
        if isinstance(data.get(key), str):
            s[key] = data[key].strip()[:limit]
    for key in ("auto_speak", "voice_send"):
        if isinstance(data.get(key), bool):
            s[key] = data[key]
    try:
        s["rate"] = round(min(1.8, max(0.6, float(data.get("rate", s["rate"])))), 2)
    except (TypeError, ValueError):
        pass
    return s


def load_settings():
    try:
        with open(settings_file(), encoding="utf-8") as f:
            return clean_settings(json.load(f))
    except (OSError, ValueError):
        return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    try:
        with open(settings_file(), "w", encoding="utf-8") as f:
            json.dump(settings, f, ensure_ascii=False, indent=1)
    except OSError as e:
        log_error(f"save_settings: {e!r}")


def key_file():
    return os.path.join(DATA_DIR, "nova_key.json")


def load_api_key():
    """Ключ Gemini: сначала тот, что вставили в настройках NOVA, потом переменная среды GEMINI_API_KEY.
    Возвращает (ключ, откуда: "file" | "env" | "")."""
    try:
        with open(key_file(), encoding="utf-8") as f:
            key = str(json.load(f).get("key", "")).strip()
        if key:
            return key, "file"
    except (OSError, ValueError, AttributeError):
        pass
    key = (os.environ.get("GEMINI_API_KEY") or "").strip().strip('"').strip("'")
    return (key, "env") if key else ("", "")


def save_api_key(key):
    with open(key_file(), "w", encoding="utf-8") as f:
        json.dump({"key": key}, f)


def key_info():
    """Что показать в настройках — сам ключ окну не отдаётся, только последние 4 символа."""
    key, source = load_api_key()
    return {"set": bool(key), "source": source, "hint": ("…" + key[-4:]) if key else ""}


def log_error(text):
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + text.rstrip() + "\n\n")
    except OSError:
        pass


def system_prompt(settings=None, role=None, tier=None):
    """Подсказка для модели: кто она, характер, оформление, файлы, интернет, сведения о пользователе,
    роль этого чата (если задана) и дата."""
    s = settings or DEFAULT_SETTINGS
    persona = PERSONAS.get(s.get("persona"), PERSONAS["friendly"])
    first = BASE_PROMPT + " " + persona["prompt"]
    if tier:
        first += (f" Сейчас ты работаешь как модель NOVA {tier['title']} ({tier['kind']}). Всего у NOVA три модели: "
                  "Note — лёгкая, Chord — средняя (обе работают на компьютере пользователя), "
                  "Symphony — сильная, через интернет.")
    parts = [first, FORMAT_PROMPT, FILES_PROMPT]
    if TOOLS:
        parts.append(LOCAL_TOOLS_PROMPT if tier and tier.get("engine") == "ollama" else INTERNET_PROMPT)
    about = []
    if s.get("name"):
        about.append(f"Пользователя зовут {s['name']} — иногда обращайся по имени, но не в каждом ответе.")
    if s.get("city"):
        about.append(f"Город пользователя — {s['city']}: если про погоду или местные дела спрашивают без города, имей в виду его.")
    if about:
        parts.append(" ".join(about))
    if s.get("custom"):
        parts.append("Особые пожелания пользователя — выполняй их:\n" + s["custom"])
    if role:
        parts.append(
            "РОЛЬ В ЭТОМ ЧАТЕ — она важнее общего характера: веди себя так, как описано ниже "
            "(ты по-прежнему NOVA, правила оформления и инструменты остаются):\n" + role
        )
    now = datetime.now()
    parts.append(f"Сейчас {now:%d.%m.%Y}, {WEEKDAYS[now.weekday()]}, {now:%H:%M} по времени компьютера пользователя.")
    return "\n\n".join(parts)


# =========================
# ВЛОЖЕНИЯ: КАРТИНКИ И ФАЙЛЫ
# Картинки и PDF Gemini «видит» сама; код, тексты и документы Word NOVA читает как текст.
# Файлы хранятся в chats/files, чтобы чат можно было открыть и продолжить позже.
# =========================

IMAGE_TYPES = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp",
    "heic": "image/heic", "heif": "image/heif",
}
TEXT_EXT = {
    "txt", "md", "markdown", "rst", "log", "csv", "tsv", "json", "jsonl", "xml", "yaml", "yml", "toml", "ini",
    "cfg", "conf", "env", "properties", "html", "htm", "css", "scss", "sass", "less", "js", "mjs", "cjs", "ts",
    "tsx", "jsx", "vue", "svelte", "py", "pyw", "ipynb", "java", "kt", "kts", "c", "h", "cpp", "hpp", "cc", "cs",
    "go", "rs", "php", "rb", "swift", "lua", "luau", "gd", "gdshader", "tscn", "tres", "sql", "sh", "bash", "bat",
    "cmd", "ps1", "psm1", "r", "m", "dart", "scala", "pl", "srt", "vtt", "tex", "svg", "gradle", "dockerfile",
}
MAX_FILES = 5
MAX_TOTAL_BYTES = 18 * 1024 * 1024  # Gemini принимает до ~20 МБ вложений в одном сообщении
MAX_TEXT_CHARS = 200_000            # очень длинный текст обрезается, чтобы не съесть лимит (~55 тыс. токенов)


def _ext(name):
    return name.rsplit(".", 1)[-1].lower() if "." in name else name.lower()


def classify_attachment(name, mime, data):
    """Что это за файл: ("image" | "pdf" | "doc" | "text", mime). Если NOVA его не прочтёт — ValueError."""
    ext = _ext(name)
    mime = (mime or "").lower()
    if ext in IMAGE_TYPES or mime in IMAGE_TYPES.values():
        return "image", IMAGE_TYPES.get(ext, mime)
    if ext == "pdf" or mime == "application/pdf":
        return "pdf", "application/pdf"
    if ext == "docx":
        return "doc", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    if ext in TEXT_EXT or mime.startswith("text/") or _looks_like_text(data):
        return "text", "text/plain"
    raise ValueError(f"Файл «{name}» NOVA пока не умеет читать. Подойдут картинки, PDF, документы Word, код и тексты.")


def _looks_like_text(data):
    head = data[:4096]
    if b"\x00" in head:
        return False
    try:
        head.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def _decode_text(data):
    for enc in ("utf-8-sig", "cp1251"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")


def _docx_text(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"</w:p>", "\n", xml)
    xml = re.sub(r"<w:tab/>", "\t", xml)
    return html.unescape(re.sub(r"<[^>]+>", "", xml)).strip()


def attachment_text(kind, data):
    """Текст файла для модели (код, тексты, документы Word). Длинный — обрезается с пометкой."""
    text = _docx_text(data) if kind == "doc" else _decode_text(data)
    if len(text) > MAX_TEXT_CHARS:
        text = text[:MAX_TEXT_CHARS] + f"\n\n[… файл обрезан: показаны первые {MAX_TEXT_CHARS} символов]"
    return text


def _safe_name(name):
    base = re.sub(r"[^\w.-]+", "_", name, flags=re.UNICODE).strip("._")
    return (base or "file")[-60:]


def store_attachment(chat_id, name, data):
    """Сохранить вложение рядом с чатом. Возвращает имя сохранённого файла."""
    os.makedirs(files_dir(), exist_ok=True)
    stored = f"{chat_id}-{uuid.uuid4().hex[:8]}-{_safe_name(name)}"
    with open(os.path.join(files_dir(), stored), "wb") as f:
        f.write(data)
    return stored


def attachment_path(stored):
    if not re.fullmatch(r"[\w.-]{1,200}", stored or "", flags=re.UNICODE) or ".." in stored:
        raise ValueError("bad file name")
    return os.path.join(files_dir(), stored)


def read_attachment(stored):
    with open(attachment_path(stored), "rb") as f:
        return f.read()


def delete_chat_files(chat_id):
    try:
        for name in os.listdir(files_dir()):
            if name.startswith(chat_id + "-"):
                os.remove(os.path.join(files_dir(), name))
    except OSError:
        pass


# =========================
# ИНТЕРНЕТ: ИНСТРУМЕНТЫ NOVA
# Gemini сама решает, когда их вызвать. Всё бесплатно и без ключей.
# Каждая функция ловит свои ошибки и возвращает {"error": ...}, чтобы модель могла
# объяснить, что не получилось, а не падала.
# =========================

found_sources = []   # источники текущего ответа: [подпись, ссылка, сайт для значка]
_progress = None     # куда сообщать «ищу в интернете…» (задаёт интерфейс)


def set_progress(callback):
    global _progress
    _progress = callback


def report(text):
    if _progress:
        _progress(text)


try:
    import httpx  # ставится вместе с google-genai

    http = httpx.Client(
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/140.0 Safari/537.36",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
        },
        timeout=httpx.Timeout(12.0, connect=4.0),  # долго «стучаться» нет смысла — лучше повторить
        follow_redirects=True,
    )
except ImportError:
    http = None


def fetch(url, **kwargs):
    """Скачать страницу; при сетевом сбое — ещё одна попытка (сеть иногда подвисает на секунду)."""
    for attempt in range(2):
        try:
            r = http.request("GET", url, **kwargs)
            if r.status_code >= 500 and attempt == 0:
                time.sleep(0.5)
                continue
            return r
        except httpx.TransportError:
            if attempt:
                raise
            time.sleep(0.5)


def domain_of(url):
    host = urlparse(url or "").netloc.lower()
    return host[4:] if host.startswith("www.") else host


def add_source(label, url, site=None):
    if url and len(found_sources) < 5 and all(url != s[1] and label != s[0] for s in found_sources):
        found_sources.append([label, url, site or domain_of(url)])


def clean_html(text):
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", text or ""))).strip()


def wikipedia_search(query):
    try:
        r = fetch(
            "https://ru.wikipedia.org/w/api.php",
            params={"action": "query", "list": "search", "srsearch": query, "format": "json", "srlimit": 4},
        )
        return [
            {
                "title": x["title"],
                "url": "https://ru.wikipedia.org/wiki/" + quote(x["title"].replace(" ", "_")),
                "snippet": clean_html(x.get("snippet", "")),
            }
            for x in r.json()["query"]["search"]
        ]
    except Exception as e:
        log_error(f"wikipedia_search: {e!r}")
        return []


def web_search(query: str) -> dict:
    """Поиск в интернете. Используй для свежих и проверяемых фактов: цены, курсы криптовалют,
    события, релизы, спорт, люди, «что такое…», а также когда пользователь просит что-то найти.
    Возвращает заголовки, ссылки и короткие описания найденных страниц.

    Args:
        query: поисковый запрос
    """
    report(f"Ищу в интернете: {query}")
    items = []
    try:
        r = fetch("https://search.yahoo.com/search", params={"p": query, "ei": "UTF-8"})
        for block in re.findall(r'<div class="[^"]*algo[^"]*"(.*?)</li>', r.text, re.S):
            link = re.search(r'<a[^>]*href="([^"]+)"', block)
            title = re.search(r"<h3[^>]*>(.*?)</h3>", block, re.S)
            snippet = re.search(r'<div class="compText[^"]*"[^>]*>(.*?)</div>', block, re.S)
            if not (link and title):
                continue
            url = html.unescape(link.group(1))
            real = re.search(r"/RU=([^/]+)/R[KS]=", url)  # у Yahoo ссылки через переадресацию
            if real:
                url = unquote(real.group(1))
            if not url.startswith("http") or "yahoo.com" in domain_of(url):
                continue
            items.append({
                "title": clean_html(title.group(1)),
                "url": url,
                "snippet": clean_html(snippet.group(1)) if snippet else "",
            })
            if len(items) >= 6:
                break
    except Exception as e:
        log_error(f"web_search: {e!r}")

    if not items:
        items = wikipedia_search(query)
    if not items:
        return {"error": "Поиск ничего не нашёл или сейчас недоступен. Попробуй другой запрос."}
    for item in items[:3]:
        add_source(domain_of(item["url"]), item["url"])
    return {"results": items}


def _read_rss(url, limit=8):
    try:
        r = fetch(url)
        r.raise_for_status()
        import xml.etree.ElementTree as ET
        items = []
        for it in ET.fromstring(r.content).iter("item"):
            source = it.find("source")
            when = ""
            try:
                when = parsedate_to_datetime(it.findtext("pubDate")).astimezone().strftime("%d.%m %H:%M")
            except Exception:
                pass
            items.append({
                "title": clean_html(it.findtext("title")),
                "source": source.text if source is not None else "",
                "site": domain_of(source.get("url")) if source is not None else "",
                "date": when,
                "url": it.findtext("link") or "",
            })
            if len(items) >= limit:
                break
        return items
    except Exception as e:
        log_error(f"rss {domain_of(url)}: {e!r}")
        return []


def news_search(topic: str) -> dict:
    """Свежие новости. Используй, когда спрашивают про новости, события, «что случилось», «что нового».

    Args:
        topic: конкретная тема (например «космос», «футбол», «Apple»); для главных новостей дня — пустая строка
    """
    topic = (topic or "").strip()
    # «главные новости», «что нового сегодня» и т.п. — это не тема, а просьба о ленте дня
    generic = r"главн\w*|последн\w*|свеж\w*|важн\w*|новост\w*|сегодн\w*|дня|день|мира|мир|в|за|россии|news|top|today|latest"
    if not re.sub(rf"\b({generic})\b", "", topic.lower()).strip(" ,.!?"):
        topic = ""
    report("Смотрю новости" + (f": {topic}" if topic else " дня"))
    if topic:
        items = _read_rss("https://news.google.com/rss/search?q=" + quote_plus(topic + " when:3d")
                          + "&hl=ru&gl=RU&ceid=RU:ru")
    else:
        items = _read_rss("https://news.google.com/rss?hl=ru&gl=RU&ceid=RU:ru")
    if not items:
        items = _read_rss("https://www.bing.com/news/search?format=rss&setlang=ru&q="
                          + quote_plus(topic or "главные новости"))
    if not items:
        return {"error": "Не удалось загрузить новости. Возможно, нет интернета."}
    for item in items[:4]:
        add_source(item["source"] or domain_of(item["url"]), item["url"], item.get("site"))
    return {"news": [{k: v for k, v in it.items() if k != "site"} for it in items]}


WEATHER_CODES = {
    0: "ясно", 1: "преимущественно ясно", 2: "переменная облачность", 3: "пасмурно",
    45: "туман", 48: "туман с изморозью", 51: "слабая морось", 53: "морось", 55: "сильная морось",
    56: "ледяная морось", 57: "сильная ледяная морось", 61: "небольшой дождь", 63: "дождь",
    65: "сильный дождь", 66: "ледяной дождь", 67: "сильный ледяной дождь", 71: "небольшой снег",
    73: "снег", 75: "сильный снег", 77: "снежная крупа", 80: "небольшой ливень", 81: "ливень",
    82: "сильный ливень", 85: "снегопад", 86: "сильный снегопад", 95: "гроза",
    96: "гроза с градом", 99: "сильная гроза с градом",
}


def get_weather(city: str) -> dict:
    """Погода сейчас и прогноз на 3 дня для указанного города.

    Args:
        city: название города, например «Москва»
    """
    report(f"Узнаю погоду: {city}")
    try:
        found = fetch(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": city, "count": 1, "language": "ru"},
        ).json().get("results")
        if not found:
            return {"error": f"Город «{city}» не найден. Уточни название."}
        place = found[0]
        w = fetch(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": place["latitude"], "longitude": place["longitude"],
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                "timezone": "auto", "forecast_days": 3, "wind_speed_unit": "ms",
            },
        ).json()
        cur, day = w["current"], w["daily"]
        add_source("Open-Meteo", "https://open-meteo.com/")
        return {
            "place": ", ".join(x for x in (place.get("name"), place.get("admin1"), place.get("country")) if x),
            "now": {
                "time": cur["time"].replace("T", " "),
                "temperature_c": cur["temperature_2m"],
                "feels_like_c": cur["apparent_temperature"],
                "humidity_percent": cur["relative_humidity_2m"],
                "wind_m_s": cur["wind_speed_10m"],
                "sky": WEATHER_CODES.get(cur["weather_code"], "?"),
            },
            "forecast": [
                {
                    "date": day["time"][i],
                    "min_c": day["temperature_2m_min"][i],
                    "max_c": day["temperature_2m_max"][i],
                    "sky": WEATHER_CODES.get(day["weather_code"][i], "?"),
                    "precipitation_chance_percent": day["precipitation_probability_max"][i],
                }
                for i in range(len(day["time"]))
            ],
        }
    except Exception as e:
        log_error(f"get_weather: {e!r}")
        return {"error": f"Не удалось узнать погоду: {e}"}


def get_exchange_rates(currencies: str) -> dict:
    """Официальные курсы валют ЦБ РФ к рублю на сегодня. Для криптовалют используй web_search.

    Args:
        currencies: коды валют через запятую, например «USD,EUR,CNY»
    """
    report("Смотрю курсы ЦБ")
    try:
        data = fetch("https://www.cbr-xml-daily.ru/daily_json.js").json()
        codes = [c.upper() for c in re.split(r"[,\s;]+", currencies or "") if c] or ["USD", "EUR", "CNY"]
        rates = {}
        for code in codes:
            v = data["Valute"].get(code)
            if v:
                rates[code] = {
                    "name": v["Name"],
                    "rub_for_1": round(v["Value"] / v["Nominal"], 4),
                    "change_since_previous": round((v["Value"] - v["Previous"]) / v["Nominal"], 4),
                }
            else:
                rates[code] = "ЦБ не публикует курс этой валюты"
        add_source("ЦБ РФ", "https://www.cbr.ru/currency_base/daily/")
        return {"date": data["Date"][:10], "rates": rates}
    except Exception as e:
        log_error(f"get_exchange_rates: {e!r}")
        return {"error": f"Не удалось получить курсы: {e}"}


class _PageText(HTMLParser):
    """Достаёт текст из HTML. Если на странице есть <main>/<article> — запоминает их отдельно,
    чтобы читать саму статью, а не меню сайта."""
    SKIP = {"script", "style", "noscript", "svg", "nav", "footer", "form", "aside", "iframe", "header"}
    BREAK = {"p", "div", "li", "h1", "h2", "h3", "h4", "br", "tr", "section", "article"}
    MAIN = {"main", "article"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.main_parts = [], []
        self.title, self.skip, self.main, self.in_title = "", 0, 0, False

    def _add(self, text):
        self.parts.append(text)
        if self.main:
            self.main_parts.append(text)

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag == "title":
            self.in_title = True
        else:
            if tag in self.MAIN:
                self.main += 1
            if tag in self.BREAK:
                self._add("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        elif tag == "title":
            self.in_title = False
        else:
            if tag in self.BREAK:
                self._add("\n")
            if tag in self.MAIN and self.main:
                self.main -= 1

    def handle_data(self, data):
        if self.in_title:
            self.title += data
        elif not self.skip:
            self._add(data)


def read_webpage(url: str) -> dict:
    """Открывает страницу по ссылке и возвращает её текст. Используй, когда пользователь дал ссылку
    или когда коротких описаний из поиска не хватает для точного ответа.

    Args:
        url: полная ссылка на страницу, начиная с http
    """
    report(f"Читаю {domain_of(url) or url}")
    try:
        r = fetch(url)
        kind = r.headers.get("content-type", "")
        if "html" not in kind and "text" not in kind:
            return {"error": f"Это не веб-страница ({kind or 'неизвестный тип'}), прочитать не могу."}
        page = _PageText()
        page.feed(r.text)
        main_text = "".join(page.main_parts)
        raw = main_text if len(main_text.strip()) > 400 else "".join(page.parts)
        lines = [re.sub(r"\s+", " ", line).strip() for line in raw.splitlines()]
        text = "\n".join(line for line in lines if len(line) > 2)
        add_source(domain_of(str(r.url)), str(r.url))
        return {"title": page.title.strip(), "text": text[:6000]}
    except Exception as e:
        log_error(f"read_webpage {url}: {e!r}")
        return {"error": f"Не удалось открыть страницу: {e}"}


TOOLS = [web_search, news_search, get_weather, get_exchange_rates, read_webpage] if http else []


# =========================
# МОЗГ: Symphony (Gemini) и свои модели Note и Chord (Ollama на этом компьютере)
# =========================

DEFAULT_ATTACH_PROMPT = "Посмотри вложения и расскажи, что там."
GEMINI_LIGHT = "gemini-flash-lite-latest"  # для проверки ключа и названий чатов — самая быстрая
OLLAMA_URL = "http://127.0.0.1:11434"
OLLAMA_TOOL_RESULT_LIMIT = 6000  # у локальных моделей контекст небольшой — результаты поиска сокращаем


class ClientGone(Exception):
    """Окно перестало ждать ответ (нажали «стоп» или закрыли)."""


# --- Ollama: нейросети на своём компьютере ---

try:
    # trust_env=False: Ollama живёт на этом же компьютере — системный прокси (VPN) ему не нужен, а иначе
    # Python гонит даже 127.0.0.1 через прокси (исключения Windows он не учитывает), и запросы зависают.
    ollama_http = httpx.Client(timeout=httpx.Timeout(180.0, connect=2.0), trust_env=False)
except NameError:  # нет httpx — локальные модели недоступны
    ollama_http = None

_ollama_state = {"checked": 0.0, "models": None}


def ollama_models(max_age=4.0):
    """Скачанные модели Ollama (имена) или None, если Ollama не запущен."""
    now = time.time()
    if now - _ollama_state["checked"] < max_age:
        return _ollama_state["models"]
    models = None
    if ollama_http is not None:
        try:
            r = ollama_http.get(OLLAMA_URL + "/api/tags", timeout=1.5)
            models = [m["name"] for m in r.json().get("models", [])]
        except Exception:
            models = None
    _ollama_state.update(checked=now, models=models)
    return models


def ollama_loaded():
    """Какие модели сейчас уже в видеокарте (отвечают сразу)."""
    try:
        return [m["name"] for m in ollama_http.get(OLLAMA_URL + "/api/ps", timeout=1.5).json().get("models", [])]
    except Exception:
        return []


def ollama_exe():
    path = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe")
    if os.path.exists(path):
        return path
    import shutil
    return shutil.which("ollama")


def ensure_ollama(wait_sec=15):
    """Ollama установлен, но не запущен — запустить его тихо, без окна."""
    if ollama_models(0) is not None:
        return True
    exe = ollama_exe()
    if not exe:
        return False
    env = dict(os.environ)
    if not env.get("OLLAMA_MODELS"):  # где лежат модели (например, на диске D) — из настроек пользователя
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                env["OLLAMA_MODELS"] = winreg.QueryValueEx(k, "OLLAMA_MODELS")[0]
        except OSError:
            pass
    try:
        subprocess.Popen([exe, "serve"], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        return False
    for _ in range(int(wait_sec * 2)):
        time.sleep(0.5)
        if ollama_models(0) is not None:
            return True
    return False


def _tool_schema(fn):
    """Описание инструмента для Ollama — из названия, подписи и описания самой функции."""
    doc = inspect.getdoc(fn) or ""
    desc, _, args_doc = doc.partition("Args:")
    props = {}
    for name in inspect.signature(fn).parameters:
        m = re.search(rf"^\s*{name}:\s*(.+)$", args_doc, re.M)
        props[name] = {"type": "string", "description": m.group(1).strip() if m else name}
    return {"type": "function", "function": {
        "name": fn.__name__, "description": " ".join(desc.split()),
        "parameters": {"type": "object", "properties": props, "required": list(props)},
    }}


TOOL_SCHEMAS = [_tool_schema(f) for f in TOOLS]
TOOL_MAP = {f.__name__: f for f in TOOLS}

# Маленькие модели иногда «вспоминают» курсы и цены вместо поиска. Поэтому на такие вопросы NOVA
# сама заранее берёт свежие данные и даёт модели готовый результат.
CURRENCY_WORDS = {
    "доллар": "USD", "бакс": "USD", "usd": "USD", "евро": "EUR", "eur": "EUR", "юан": "CNY", "cny": "CNY",
    "фунт": "GBP", "иен": "JPY", "йен": "JPY", "тенге": "KZT", "гривн": "UAH", "белорусск": "BYN",
    "лир": "TRY", "франк": "CHF", "дирхам": "AED",
}
CRYPTO_RE = re.compile(r"биткоин|биткойн|bitcoin|\bbtc\b|эфириум|ethereum|\beth\b|крипт|toncoin|тонкоин|dogecoin|солан|solana", re.I)
PRICE_RE = re.compile(r"сколько\s+(сейчас\s+|сегодня\s+)?сто[ия]т|\bцен[аы]\b|стоимост", re.I)
RATE_RE = re.compile(r"\bкурс", re.I)


def prefetch_calls(question):
    """Какие инструменты вызвать заранее для лёгких моделей: [(имя, аргументы)]."""
    q = (question or "").lower()
    if CRYPTO_RE.search(q):
        return [("web_search", {"query": question.strip()[:200]})]
    codes = []
    for word, code in CURRENCY_WORDS.items():
        if word in q and code not in codes:
            codes.append(code)
    if (codes and (RATE_RE.search(q) or PRICE_RE.search(q))) or (RATE_RE.search(q) and "валют" in q):
        return [("get_exchange_rates", {"currencies": ",".join(codes) or "USD,EUR,CNY"})]
    if PRICE_RE.search(q):
        return [("web_search", {"query": question.strip()[:200]})]
    return []


def run_tool(name, args):
    """Выполнить инструмент, который попросила локальная модель. Ошибки возвращаются ей же текстом."""
    fn = TOOL_MAP.get(name)
    if not fn:
        return {"error": f"нет инструмента {name}"}
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except ValueError:
            args = {}
    if not isinstance(args, dict):
        args = {}
    params = list(inspect.signature(fn).parameters)
    try:
        if all(p in args for p in params):
            return fn(**{p: str(args[p]) for p in params})
        if len(params) == 1 and args:  # модель назвала параметр по-своему
            return fn(str(next(iter(args.values()))))
        return fn(*["" for _ in params])
    except Exception as e:
        log_error(f"run_tool {name}: {e!r}")
        return {"error": str(e)}


class NovaBrain:
    """Разговор хранится в self.turns: [{"role": "user"/"model", "text": ..., "atts": [вложения]}].
    Перед каждым вопросом из него собирается история для выбранной модели — только текст и вложения,
    поэтому модель можно сменить посреди разговора, и NOVA ничего не забудет."""

    def __init__(self, settings):
        self.settings = settings  # общий словарь настроек: окно меняет его, NOVA сразу это видит
        self.client = None
        self.turns = []
        self.gemini_problem = ""  # почему Symphony недоступна (пусто, если всё хорошо)
        self.last_model = None
        self.lock = threading.Lock()
        self._parts = {}  # уже прочитанные вложения, чтобы не читать файлы с диска каждый раз

        self.genai = self.errors = self.types = None
        try:
            from google import genai
            from google.genai import errors, types
        except ImportError:
            self.gemini_problem = (
                "Не установлена библиотека google-genai. Запусти «Install NOVA.bat» "
                "или выполни в терминале:  py -m pip install -U google-genai"
            )
            return

        self.genai, self.errors, self.types = genai, errors, types
        self.connect()

    # --- Gemini: подключение и ключ ---

    def _make_client(self, key, timeout_sec=REQUEST_TIMEOUT_SEC):
        return self.genai.Client(api_key=key, http_options=self.types.HttpOptions(timeout=timeout_sec * 1000))

    def connect(self, key=None):
        """Подключиться к Gemini с ключом из настроек NOVA или переменной среды GEMINI_API_KEY."""
        if self.genai is None:
            return
        key = key or load_api_key()[0]
        if not key:
            self.client = None
            self.gemini_problem = (
                "Для Symphony нужен ключ Gemini. Это бесплатно: открой ⚙ Настройки → «Ключ Gemini» "
                "и вставь ключ с aistudio.google.com."
            )
            return
        try:
            self.client = self._make_client(key)
            self.gemini_problem = ""
        except Exception as e:
            log_error(traceback.format_exc())
            self.client = None
            self.gemini_problem = f"Не удалось подключиться к Gemini: {e}"

    def check_key(self, key):
        """Проверить ключ настоящим коротким запросом. Возвращает (годится ли, объяснение)."""
        if self.genai is None:
            return False, self.gemini_problem
        try:
            client = self._make_client(key, timeout_sec=25)
            client.models.generate_content(
                model=GEMINI_LIGHT, contents="Ответь одним словом: ок",
                config=self.types.GenerateContentConfig(max_output_tokens=5),
            )
            return True, "Ключ работает"
        except Exception as e:
            if getattr(e, "code", None) == 429:  # лимит — значит, ключ настоящий
                return True, "Ключ работает (сейчас лимит запросов, подожди минуту)"
            log_error(f"check_key: {e!r}")
            return False, explain_error(e)

    # --- какая модель выбрана и готова ли она ---

    @property
    def gemini_ready(self):
        return self.client is not None

    @property
    def mode(self):
        mode = self.settings.get("mode")
        return mode if mode in MODES else DEFAULT_MODE

    def status(self, mode=None):
        """(готова ли модель, а если нет — почему)."""
        mode = mode if mode in MODES else self.mode
        cfg = MODES[mode]
        if cfg["engine"] == "gemini":
            return self.gemini_ready, self.gemini_problem
        name = cfg["models"][0][0]
        models = ollama_models()
        if models is None:
            if ollama_exe():
                return True, ""  # установлен, но не запущен — NOVA запустит его сама при первом вопросе
            return False, (f"Для {cfg['title']} нужен Ollama — бесплатная программа, которая запускает нейросети "
                           "на твоём компьютере. Скачай его с ollama.com или выбери Symphony.")
        if name not in models:
            return False, f"Модель {cfg['title']} ещё не скачана. Открой терминал и выполни:  ollama pull {name}"
        return True, ""

    @property
    def ready(self):
        return self.status()[0]

    @property
    def problem(self):
        return self.status()[1]

    @property
    def model(self):
        names = [m for m, _ in MODES[self.mode]["models"]]
        return self.last_model if self.last_model in names else names[0]

    def reset(self):
        with self.lock:
            self.turns = []

    def set_mode(self, mode):
        """Сменить модель, не теряя разговор."""
        with self.lock:
            self.settings["mode"] = mode
            self.last_model = None

    def load_history(self, saved_messages):
        """Продолжить сохранённый чат: NOVA снова помнит весь разговор (и вложения)."""
        with self.lock:
            self.turns = turns_from_messages(saved_messages)

    # --- сборка сообщений для Gemini ---

    def _attachment_part(self, att):
        key = att.get("stored", "")
        if key in self._parts:
            return self._parts[key]
        Part = self.types.Part
        try:
            data = read_attachment(key)
            if att["kind"] in ("image", "pdf"):
                part = Part.from_bytes(data=data, mime_type=att["mime"])
            else:
                part = Part(text=f"📎 Файл «{att['name']}» — начало:\n{attachment_text(att['kind'], data)}\n"
                                 f"📎 Конец файла «{att['name']}».")
        except Exception as e:
            log_error(f"attachment {key}: {e!r}")
            part = Part(text=f"[вложение «{att.get('name')}» не найдено на диске]")
        if len(self._parts) > 24:
            self._parts.clear()
        self._parts[key] = part
        return part

    def _user_parts(self, text, atts, full=True):
        Part = self.types.Part
        parts = [
            self._attachment_part(a) if full else Part(text=f"[раньше было вложение «{a.get('name')}»]")
            for a in atts
        ]
        parts.append(Part(text=text or DEFAULT_ATTACH_PROMPT))
        return parts

    def _history(self, turns):
        """История для Gemini: последние реплики; вложения — целиком только у последних сообщений."""
        turns = turns[-MAX_HISTORY:]
        while turns and turns[0]["role"] != "user":
            turns = turns[1:]
        with_atts = [i for i, t in enumerate(turns) if t.get("atts")]
        keep = set(with_atts[-KEEP_ATTACHMENTS:])
        contents = []
        for i, t in enumerate(turns):
            if t["role"] == "user":
                parts = self._user_parts(t["text"], t.get("atts") or [], full=i in keep)
            else:
                parts = [self.types.Part(text=t["text"] or "…")]
            if contents and contents[-1].role == t["role"]:
                contents[-1].parts.extend(parts)
            else:
                contents.append(self.types.Content(role=t["role"], parts=parts))
        return contents

    # --- сборка сообщений для Ollama ---

    @staticmethod
    def _ollama_user_text(text, atts, full, limit):
        chunks = []
        for a in atts:
            kind, name = a.get("kind"), a.get("name", "файл")
            if kind in ("text", "doc") and full:
                try:
                    body = attachment_text(kind, read_attachment(a["stored"]))
                except Exception:
                    body = "[файл не найден на диске]"
                if len(body) > limit:
                    body = body[:limit] + f"\n[… дальше обрезано: эта модель видит только первые {limit} символов файла]"
                chunks.append(f"📎 Файл «{name}» — начало:\n{body}\n📎 Конец файла «{name}».")
            elif kind in ("image", "pdf"):
                chunks.append(f"[вложение «{name}» ({'картинка' if kind == 'image' else 'PDF'}) — его смотрела модель Symphony]")
            else:
                chunks.append(f"[раньше было вложение «{name}»]")
        chunks.append(text or DEFAULT_ATTACH_PROMPT)
        return "\n\n".join(chunks)

    def _ollama_messages(self, base, message, atts, role, cfg):
        ctx = cfg.get("ctx", 8192)
        budget = int(ctx * 2.6) - 6000             # примерно символов на историю (остальное — на ответ)
        file_limit = max(3000, budget // 2)        # один файл не больше половины
        turns = base[-MAX_HISTORY:]
        with_atts = [i for i, t in enumerate(turns) if t.get("atts")]
        keep = set(with_atts[-1:])                  # файлы целиком — только из последнего сообщения с файлами
        history = []
        for i, t in enumerate(turns):
            if t["role"] == "user":
                history.append({"role": "user", "content": self._ollama_user_text(t["text"], t.get("atts") or [], i in keep, file_limit)})
            else:
                history.append({"role": "assistant", "content": t["text"] or "…"})
        question = {"role": "user", "content": self._ollama_user_text(message, atts, True, file_limit)}
        # не влезает в память модели — забываем самое старое
        while history and sum(len(m["content"]) for m in history) + len(question["content"]) > budget:
            history.pop(0)
        while history and history[0]["role"] != "user":
            history.pop(0)
        return [{"role": "system", "content": system_prompt(self.settings, role, cfg)}] + history + [question]

    def _ollama_round(self, model, msgs, cfg, emit, pieces, separate):
        """Один заход к модели: текст идёт в окно кусочками, вызовы инструментов возвращаются."""
        payload = {"model": model, "messages": msgs, "stream": True, "think": False, "keep_alive": "30m",
                   "options": {"num_ctx": cfg.get("ctx", 8192)}}
        if TOOL_SCHEMAS:
            payload["tools"] = TOOL_SCHEMAS
        calls = []
        with ollama_http.stream("POST", OLLAMA_URL + "/api/chat", json=payload) as r:
            if r.status_code != 200:
                raise RuntimeError(r.read().decode("utf-8", "replace")[:300])
            for line in r.iter_lines():
                if not line:
                    continue
                ev = json.loads(line)
                if ev.get("error"):
                    raise RuntimeError(ev["error"])
                msg = ev.get("message") or {}
                piece = msg.get("content") or ""
                if piece:
                    if not pieces and separate:
                        emit("delta", "\n\n")
                    pieces.append(piece)
                    emit("delta", piece)
                calls += msg.get("tool_calls") or []
                if ev.get("done"):
                    break
        return calls

    def _ollama_simple(self, model, prompt, max_tokens=40):
        r = ollama_http.post(OLLAMA_URL + "/api/chat", timeout=60, json={
            "model": model, "messages": [{"role": "user", "content": prompt}], "stream": False, "think": False,
            "keep_alive": "30m", "options": {"num_predict": max_tokens, "temperature": 0.3},
        })
        return (r.json().get("message") or {}).get("content", "")

    # --- вопросы ---

    def suggest_title(self, question, answer):
        """Короткое название чата по первому вопросу и ответу (как в ChatGPT). None — если не вышло."""
        prompt = (
            "Придумай короткое название чата: 2–5 слов, на языке вопроса, отражает суть. "
            "Без кавычек и точки в конце. Ответь только названием.\n\n"
            f"Вопрос: {(question or 'вложения')[:500]}\nОтвет: {answer[:500]}"
        )
        try:
            if self.gemini_ready:
                r = self.client.models.generate_content(
                    model=GEMINI_LIGHT, contents=prompt,
                    config=self.types.GenerateContentConfig(temperature=0.3, max_output_tokens=24),
                )
                raw = r.text or ""
            else:  # без ключа — название придумает лёгкая модель на компьютере
                local = next((k for k, v in MODES.items() if v["engine"] == "ollama" and self.status(k)[0]), None)
                if not local or ollama_models() is None:
                    return None
                raw = self._ollama_simple(MODES[local]["models"][0][0], prompt)
            title = raw.strip().splitlines()[0].strip(' "«»„“*.') if raw.strip() else ""
            return title[:60] if len(title) >= 2 else None
        except Exception as e:
            log_error(f"suggest_title: {e!r}")
            return None

    def ask_stream(self, message, emit, atts=None, role=None):
        """Спросить NOVA и получать ответ кусочками. role — роль этого чата (если задана).

        emit("delta", текст) — очередной кусок ответа; emit("reset", None) — начать ответ заново
        (попытка сорвалась посреди ответа и NOVA пробует ещё раз). emit может бросить ClientGone.
        Возвращает (полный текст, вид, источники), вид — "ai", "error" или "stopped".
        """
        atts = atts or []
        cfg = MODES[self.mode]
        eyes = lambda items: [a for a in items or [] if a.get("kind") in ("image", "pdf")]
        last_user = next((t for t in reversed(self.turns) if t["role"] == "user"), None)
        if cfg["engine"] == "ollama" and (eyes(atts) or (last_user and eyes(last_user.get("atts")))):
            # локальные модели не видят картинки и PDF — это сообщение (и уточнение сразу после него) берёт Symphony
            if not self.gemini_ready:
                if not eyes(atts):
                    pass  # уточнение без ключа — пусть отвечает своя модель по описанию
                else:
                    return ("Картинки и PDF видит только Symphony, а ей нужен ключ Gemini: "
                            "⚙ Настройки → «Ключ Gemini». Код и тексты Note и Chord читают сами.", "error", [])
            else:
                seen = eyes(atts) or eyes(last_user.get("atts"))
                what = "картинку" if all(a["kind"] == "image" for a in seen) else "PDF"
                report(f"Symphony смотрит {what}" if eyes(atts) else f"Про {what} отвечает Symphony — она её видела")
                cfg = MODES[STRONG_MODE]
        if cfg["engine"] == "gemini" and not self.gemini_ready:
            return self.gemini_problem, "error", []

        with self.lock:
            base = list(self.turns)  # разговор до этого вопроса

            def remember(answer):
                self.turns = base + [
                    {"role": "user", "text": message, "atts": atts},
                    {"role": "model", "text": answer, "atts": []},
                ]

            if cfg["engine"] == "ollama":
                return self._ask_ollama(base, message, atts, role, emit, cfg, remember)
            return self._ask_gemini(base, message, atts, role, emit, cfg, remember)

    def _ask_ollama(self, base, message, atts, role, emit, cfg, remember):
        model = cfg["models"][0][0]
        if not ensure_ollama():
            return self.status()[1] or "Ollama не запустился. Открой его из меню «Пуск» и попробуй ещё раз.", "error", []
        if model not in (ollama_models(0) or []):
            return f"Модель {cfg['title']} не скачана. Открой терминал и выполни:  ollama pull {model}", "error", []
        if model not in ollama_loaded():
            report(f"Загружаю {cfg['title']} в видеокарту — в первый раз это может занять до минуты")
        msgs = self._ollama_messages(base, message, atts, role, cfg)
        found_sources.clear()
        rounds = []
        try:
            pre = prefetch_calls(message)
            if pre:  # свежие данные — заранее, как будто модель сама их попросила
                msgs.append({"role": "assistant", "content": "",
                             "tool_calls": [{"function": {"name": n, "arguments": a}} for n, a in pre]})
                for n, a in pre:
                    msgs.append({"role": "tool", "tool_name": n,
                                 "content": json.dumps(run_tool(n, a), ensure_ascii=False)[:OLLAMA_TOOL_RESULT_LIMIT]})
            for _ in range(7):  # ответ + до 6 походов в интернет
                pieces = []
                rounds.append(pieces)
                calls = self._ollama_round(model, msgs, cfg, emit, pieces, separate=any(rounds[:-1]))
                if not calls:
                    break
                msgs.append({"role": "assistant", "content": "".join(pieces), "tool_calls": calls})
                for c in calls:
                    fn = c.get("function") or {}
                    result = run_tool(fn.get("name"), fn.get("arguments"))
                    msgs.append({"role": "tool", "tool_name": fn.get("name"),
                                 "content": json.dumps(result, ensure_ascii=False)[:OLLAMA_TOOL_RESULT_LIMIT]})
            answer = "\n\n".join("".join(p).strip() for p in rounds if "".join(p).strip())
            if not answer:
                return "Модель ничего не ответила. Попробуй переформулировать вопрос.", "error", []
            self.last_model = model
            remember(answer)
            return answer, "ai", list(found_sources)
        except ClientGone:
            partial = "\n\n".join("".join(p).strip() for p in rounds if "".join(p).strip())
            if partial:
                remember(partial)
            return partial, "stopped", list(found_sources)
        except Exception as e:
            log_error(f"[{model}] {traceback.format_exc()}")
            if any(rounds):
                emit("reset", None)
            name = type(e).__name__
            if name in ("ConnectError", "ConnectTimeout"):
                return "Ollama перестал отвечать. Перезапусти его (значок ламы в трее) или выбери Symphony.", "error", []
            if name in ("ReadTimeout", "TimeoutException"):
                return f"{cfg['title']} слишком долго молчит. Попробуй ещё раз или выбери Note.", "error", []
            text = str(e)
            if "memory" in text.lower():
                return f"Видеокарте не хватило памяти для {cfg['title']}. Закрой игры и тяжёлые программы или выбери Note.", "error", []
            return f"Модель {cfg['title']} не смогла ответить: {text[:200]}", "error", []

    def _ask_gemini(self, base, message, atts, role, emit, cfg, remember):
        models = cfg["models"]
        history = self._history(base)
        question = self._user_parts(message, atts)
        last_error = None

        # Пробуем первую модель, а если она недоступна, зависла или упёрлась в лимит — следующие.
        for step, (model, level) in enumerate(models):
            if step:
                report("Модель перегружена, пробую другую")
            config = self.types.GenerateContentConfig(
                system_instruction=system_prompt(self.settings, role, cfg),
                thinking_config=self.types.ThinkingConfig(thinking_level=level) if level else None,
                tools=TOOLS or None,
                automatic_function_calling=self.types.AutomaticFunctionCallingConfig(
                    maximum_remote_calls=6,  # не больше 6 походов в интернет на один вопрос
                ) if TOOLS else None,
            )
            for attempt in range(2):
                found_sources.clear()
                parts = []
                try:
                    chat = self.client.chats.create(model=model, config=config, history=history)
                    for chunk in chat.send_message_stream(question):
                        piece = _chunk_text(chunk)
                        if piece:
                            parts.append(piece)
                            emit("delta", piece)
                    text = "".join(parts).strip()
                    if not text:
                        return "Ответ пришёл пустым. Попробуй переформулировать вопрос.", "error", []
                    self.last_model = model
                    remember(text)
                    return text, "ai", list(found_sources)

                except ClientGone:
                    # Остановили посреди ответа: запоминаем то, что успело прийти.
                    partial = "".join(parts).strip()
                    if partial:
                        remember(partial)
                    return partial, "stopped", list(found_sources)

                except self.errors.APIError as e:
                    last_error = e
                    log_error(f"[{model}] {e}")
                    if parts:
                        emit("reset", None)
                    code = getattr(e, "code", None)
                    if code in (500, 502, 504) and attempt == 0:
                        time.sleep(1.5)
                        continue  # случайный сбой — повторить на этой же модели
                    if code in (404, 429, 500, 502, 503, 504):
                        break  # нет модели / лимит / перегрузка — сразу к следующей (у неё свой лимит)
                    return explain_error(e), "error", []  # ключ, регион, вложение — смена модели не поможет

                except Exception as e:
                    last_error = e
                    log_error(f"[{model}] {traceback.format_exc()}")
                    if parts:
                        emit("reset", None)
                    if type(e).__name__ == "ReadTimeout":
                        break  # модель подвисла — сразу пробуем следующую
                    if attempt == 0:
                        time.sleep(2)
                        continue
                    return explain_error(e), "error", []

        return explain_error(last_error), "error", []


def _chunk_text(chunk):
    """Текст из кусочка ответа (без «мыслей» модели и служебных вызовов)."""
    try:
        parts = chunk.candidates[0].content.parts or []
    except (AttributeError, IndexError, TypeError):
        return ""
    return "".join(p.text for p in parts if getattr(p, "text", None) and not getattr(p, "thought", False))


def explain_error(error):
    """Понятное объяснение ошибки вместо технической простыни."""
    text = str(error)
    low = text.lower()
    code = getattr(error, "code", None)
    name = type(error).__name__.lower()

    if "location is not supported" in low or "user location" in low:
        return "Google не пускает к Gemini из твоего региона. Включи VPN и попробуй ещё раз."
    if "api key not valid" in low or "api_key_invalid" in low or code in (401, 403):
        return ("Google не принял ключ Gemini: он неверный, удалён или отключён. Создай новый на "
                "aistudio.google.com/apikey и вставь его в ⚙ Настройки → «Ключ Gemini».")
    if code == 400 and any(w in low for w in ("payload", "too large", "exceed", "image", "inline", "mime", "pdf", "document")):
        return "Google не смог обработать вложение: оно слишком большое или повреждено. Попробуй файл поменьше."
    if code == 429:
        return ("Упёрлась в лимит бесплатных запросов Google на всех моделях. Подожди минуту. "
                "Если не помогло, значит, кончился дневной лимит — он сбросится в 11:00 по Москве.")
    if code == 404:
        return "Google отключил все модели этого режима. Их нужно обновить в MODES в nova_core.py."
    if code and code >= 500:
        return "Серверы Google сейчас перегружены или сбоят. Попробуй через минуту."
    if name == "readtimeout":
        return "Google слишком долго не отвечает на всех моделях. Попробуй ещё раз чуть позже."
    if any(w in name for w in ("connect", "timeout", "network", "ssl", "proxy")) or \
       any(w in low for w in ("getaddrinfo", "connection", "timed out", "unreachable")):
        return ("Не получилось достучаться до Google: нет интернета, или соединение блокируется. "
                "Проверь интернет. Если ты в России, Gemini работает только через VPN.")
    short_text = text if len(text) < 300 else text[:300] + "…"
    return f"Не удалось получить ответ: {short_text}"


def turns_from_messages(messages):
    """Сохранённые сообщения → разговор для NOVA. Команды («открой ютуб») не в счёт."""
    return [
        {"role": "user" if m["role"] == "user" else "model", "text": m.get("text", ""), "atts": m.get("files") or []}
        for m in messages
        if m.get("role") in ("user", "ai") and not m.get("local")
    ]


# =========================
# ИСТОРИЯ ЧАТОВ
# Каждый чат — отдельный файл в папке chats, вложения — в chats/files.
# Сохраняется после каждого сообщения.
# =========================

def make_chat():
    now = datetime.now()
    stamp = now.isoformat(timespec="seconds")
    return {
        "id": now.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6],
        "title": "Новый чат",
        "created": stamp,
        "updated": stamp,
        "messages": [],
    }


def _chat_path(chat_id):
    if not re.fullmatch(r"[\w-]{1,80}", chat_id or ""):
        raise ValueError("bad chat id")
    return os.path.join(chats_dir(), chat_id + ".json")


def save_chat(chat):
    if not chat["messages"]:
        return  # пустые чаты не храним
    try:
        os.makedirs(chats_dir(), exist_ok=True)
        path = _chat_path(chat["id"])
        with open(path + ".tmp", "w", encoding="utf-8") as f:
            json.dump(chat, f, ensure_ascii=False, indent=1)
        os.replace(path + ".tmp", path)  # сначала во временный файл — так файл не побьётся при сбое
    except (OSError, ValueError) as e:
        log_error(f"save_chat: {e!r}")


def load_chats():
    chats = {}
    try:
        names = os.listdir(chats_dir())
    except OSError:
        return chats
    for name in names:
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(chats_dir(), name), encoding="utf-8") as f:
                chat = json.load(f)
            if chat.get("messages"):
                chats[chat["id"]] = chat
        except (OSError, ValueError, KeyError) as e:
            log_error(f"load_chats {name}: {e!r}")
    return chats


def delete_chat_file(chat_id):
    try:
        os.remove(_chat_path(chat_id))
    except (OSError, ValueError) as e:
        log_error(f"delete_chat_file: {e!r}")
    delete_chat_files(chat_id)


def make_title(text, files=None):
    if text and text.strip():
        line = re.sub(r"\s+", " ", text.strip().splitlines()[0])
        return line if len(line) <= 60 else line[:58].rstrip() + "…"
    if files:
        return "📎 " + ", ".join(f["name"] for f in files)[:56]
    return "Новый чат"


# =========================
# ЭКСПОРТ И ИМПОРТ ЧАТОВ
# .md — красивый файл для чтения; .json — полная копия с вложениями, её можно импортировать обратно.
# =========================

ROLE_LIMIT = 1500
EXPORT_DIR = None  # куда сохранять экспорт вместо «Загрузок» (для проверок)


def set_export_dir(path):
    global EXPORT_DIR
    EXPORT_DIR = path


def downloads_dir():
    """Настоящая папка «Загрузки» Windows (даже если её перенесли на другой диск)."""
    if EXPORT_DIR:
        return EXPORT_DIR
    try:
        import ctypes
        from ctypes import wintypes

        class GUID(ctypes.Structure):
            _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                        ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

        downloads = GUID(0x374DE290, 0x123F, 0x4565, (ctypes.c_ubyte * 8)(0x91, 0x64, 0x39, 0xC4, 0x92, 0x5E, 0x46, 0x7B))
        path = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(downloads), 0, None, ctypes.byref(path)) == 0:
            result = path.value
            ctypes.windll.ole32.CoTaskMemFree(path)
            if result and os.path.isdir(result):
                return result
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Downloads")


def _fmt_time(iso):
    try:
        return datetime.fromisoformat(iso).strftime("%d.%m.%Y %H:%M")
    except (TypeError, ValueError):
        return ""


def chat_to_markdown(chat):
    lines = [f"# {chat['title']}", ""]
    lines.append(f"*Чат с NOVA · начат {_fmt_time(chat.get('created'))} · сообщений: {len(chat['messages'])}*")
    if chat.get("role"):
        lines += ["", "> **Роль NOVA в этом чате:** " + chat["role"].strip().replace("\n", "\n> ")]
    lines += ["", "---", ""]
    for m in chat["messages"]:
        who = "🧑 Ты" if m["role"] == "user" else "✦ NOVA"
        lines += [f"### {who} · {_fmt_time(m.get('time'))}", ""]
        if m.get("files"):
            lines += ["📎 " + ", ".join(f"`{f['name']}`" for f in m["files"]), ""]
        if m.get("text"):
            lines += [m["text"].strip(), ""]
        if m.get("stopped"):
            lines += ["*(ответ был остановлен)*", ""]
        if m.get("sources"):
            lines += ["**Источники:** " + " · ".join(f"[{s[0]}]({s[1]})" for s in m["sources"] if len(s) > 1), ""]
    lines += ["---", f"*Сохранено из NOVA {datetime.now():%d.%m.%Y %H:%M}*", ""]
    return "\n".join(lines)


def chat_to_json(chat):
    """Полная копия чата: сообщения, роль и сами файлы вложений (в base64)."""
    import base64
    files_data = {}
    for m in chat["messages"]:
        for f in m.get("files") or []:
            try:
                files_data[f["stored"]] = base64.b64encode(read_attachment(f["stored"])).decode("ascii")
            except (OSError, ValueError, KeyError):
                pass
    export = {"nova_export": 1, "exported": datetime.now().isoformat(timespec="seconds"),
              "chat": chat, "files_data": files_data}
    return json.dumps(export, ensure_ascii=False, indent=1)


def save_export(chat, fmt):
    """Сохранить чат в «Загрузки». Возвращает полный путь к файлу."""
    content = chat_to_markdown(chat) if fmt == "md" else chat_to_json(chat)
    base = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', " ", chat["title"]).strip(" .") or "Чат NOVA"
    base = base[:60].rstrip(" .")
    ext = ".md" if fmt == "md" else ".nova.json"
    folder = downloads_dir()
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, base + ext)
    n = 2
    while os.path.exists(path):
        path = os.path.join(folder, f"{base} ({n}){ext}")
        n += 1
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)
    return path


def import_chat(data):
    """Чат из .json-копии → новый чат (новый id, вложения восстанавливаются). ValueError — если файл не тот."""
    import base64
    if isinstance(data, dict) and isinstance(data.get("chat"), dict):
        source, files_data = data["chat"], data.get("files_data") or {}
    elif isinstance(data, dict) and isinstance(data.get("messages"), list):
        source, files_data = data, {}
    else:
        raise ValueError("Это не похоже на копию чата NOVA (.json).")
    if not isinstance(source.get("messages"), list) or not source["messages"]:
        raise ValueError("В файле нет сообщений.")

    chat = make_chat()
    now = chat["updated"]
    title = source.get("title")
    chat["title"] = title.strip()[:80] if isinstance(title, str) and title.strip() else "Импортированный чат"
    if isinstance(source.get("role"), str) and source["role"].strip():
        chat["role"] = source["role"].strip()[:ROLE_LIMIT]
    for key in ("created", "updated"):
        if isinstance(source.get(key), str) and _fmt_time(source[key]):
            chat[key] = source[key]

    for m in source["messages"][:5000]:
        if not isinstance(m, dict) or m.get("role") not in ("user", "ai") or not isinstance(m.get("text"), str):
            continue
        msg = {"role": m["role"], "text": m["text"][:200_000],
               "time": m["time"] if isinstance(m.get("time"), str) and _fmt_time(m["time"]) else now}
        for flag in ("local", "stopped"):
            if m.get(flag) is True:
                msg[flag] = True
        sources = [s[:3] for s in m.get("sources") or []
                   if isinstance(s, list) and len(s) >= 2 and all(isinstance(x, str) for x in s[:3])
                   and s[1].startswith(("http://", "https://"))]
        if sources:
            msg["sources"] = sources[:5]
        files = []
        for f in m.get("files") or []:
            if not isinstance(f, dict) or not isinstance(f.get("stored"), str) or f["stored"] not in files_data:
                continue
            try:
                raw = base64.b64decode(files_data[f["stored"]], validate=False)
                kind, mime = classify_attachment(str(f.get("name") or "файл")[:120], str(f.get("mime") or ""), raw)
            except (ValueError, TypeError):
                continue
            name = str(f.get("name") or "файл")[:120]
            files.append({"name": name, "kind": kind, "mime": mime,
                          "stored": store_attachment(chat["id"], name, raw), "size": len(raw)})
        if files:
            msg["files"] = files
        if msg["text"] or files:
            chat["messages"].append(msg)
    if not chat["messages"]:
        raise ValueError("В файле нет сообщений, которые можно восстановить.")
    save_chat(chat)
    return chat


# =========================
# ВСТРОЕННЫЕ КОМАНДЫ
# =========================

def open_url(url):
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False


def handle_command(message):
    """Если это команда («открой ютуб», «включи lo-fi», «загугли …») — выполнить и вернуть ответ."""
    original = message.strip()
    text = original.lower().rstrip("!. ")

    def go(url, ok_text):
        return ok_text if open_url(url) else "Не получилось открыть браузер."

    if text in ("открой гугл", "открой google", "гугл", "google"):
        return go("https://www.google.com", "Открываю **Google**.")
    if text in ("открой ютуб", "открой youtube", "ютуб", "youtube"):
        return go("https://www.youtube.com", "Открываю **YouTube**.")

    for prefix in ("найди на ютубе ", "найди в ютубе ", "включи ", "ютуб ", "youtube "):
        if text.startswith(prefix) and text[len(prefix):].strip():
            query = original[len(prefix):].strip()
            return go("https://www.youtube.com/results?search_query=" + quote_plus(query),
                      f"Ищу на YouTube: **{query}**")

    for prefix in ("загугли ", "погугли ", "найди в гугле ", "гугл ", "google "):
        if text.startswith(prefix) and text[len(prefix):].strip():
            query = original[len(prefix):].strip()
            return go("https://www.google.com/search?q=" + quote_plus(query), f"Ищу в Google: **{query}**")

    return None
