@echo off
chcp 65001 >nul
setlocal
title NOVA - установка
cd /d "%~dp0"

echo.
echo    NOVA — персональный ИИ-ассистент
echo    Установка займёт около минуты.
echo.

rem --- 1. Python ---------------------------------------------------------------
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY (
  python -c "import sys" >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo    [!] Не найден Python — NOVA работает на Python 3.10 или новее.
  echo.
  echo    Сейчас откроется страница загрузки Python.
  echo    1. Скачай и запусти установщик.
  echo    2. ВНИЗУ первого окна отметь галочку «Add python.exe to PATH».
  echo    3. После установки запусти этот файл ещё раз.
  echo.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 (
  echo    [!] Python слишком старый — нужен 3.10 или новее. Обнови его с python.org и запусти этот файл снова.
  start "" "https://www.python.org/downloads/windows/"
  pause
  exit /b 1
)
echo    [1/3] Python найден.

rem --- 2. Библиотека Gemini -----------------------------------------------------
echo    [2/3] Ставлю библиотеку Google Gemini (google-genai)...
%PY% -m pip install --user --upgrade --quiet --disable-pip-version-check google-genai
if errorlevel 1 (
  echo.
  echo    [!] Не получилось установить google-genai. Проверь интернет и запусти этот файл ещё раз.
  pause
  exit /b 1
)

rem --- 3. Ярлык и запуск ---------------------------------------------------------
echo    [3/3] Создаю ярлык NOVA на рабочем столе и запускаю...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\make_shortcut.ps1" -Launch | findstr /b "SHORTCUT_OK" >nul
if errorlevel 1 (
  echo    [!] Не получилось создать ярлык. NOVA можно запускать двойным щелчком по nova.pyw в этой папке.
  pause
  exit /b 1
)

echo.
echo    Готово! NOVA открывается.
echo    При первом запуске она попросит ключ Gemini — он бесплатный, инструкция прямо в окне.
echo    Дальше запускай NOVA ярлыком на рабочем столе.
echo.
timeout /t 8 >nul
exit /b 0
