"""
NOVA: фоновый голосовой помощник — «Нова, открой дискорд», даже когда окно NOVA закрыто.

Как устроено (распознавание — только на этом компьютере, в интернет уходит лишь текст ответа для озвучки):
  • микрофон читается средствами Windows (winmm), 16 кГц, кусками по 32 мс;
  • Silero VAD (идёт вместе с faster-whisper) замечает, что кто-то говорит; в тишине ничего не происходит;
  • сказанную фразу целиком распознаёт Whisper на видеокарте (≈0,3 с). Подсказка «Нова, …» помогает ему
    не путать имя со «снова»;
  • NOVA реагирует только на фразы с «Нова». «Нова» без команды — 8 секунд слушает без имени;
  • отвечает голосом edge-tts (Светлана), если не вышло — голосом Windows (Ирина).

Снаружи (nova.pyw) приходят: ask(текст) → (ответ, кнопки), confirm(id, да/нет) → (ok, текст),
open_window(), turn_off() и словарь настроек.
"""

import asyncio
import ctypes
import hashlib
import shutil
import ctypes.wintypes as wt
import io
import json
import math
import os
import queue
import random
import re
import subprocess
import sys
import tempfile
import threading
import time
import wave
from collections import OrderedDict, deque
from datetime import datetime

log = print  # nova_core подставит свой журнал ошибок

MODEL = "small"
RATE = 16000
CHUNK = 512  # 32 мс — столько ждёт Silero VAD
PROMPT = "Нова, открой дискорд. Нова, привет. Нова, который час?"
APP_DIR = os.path.dirname(os.path.abspath(__file__))


# =========================
# МИКРОФОН (winmm, без сторонних библиотек)
# =========================

class WAVEFORMATEX(ctypes.Structure):
    _fields_ = [("wFormatTag", wt.WORD), ("nChannels", wt.WORD), ("nSamplesPerSec", wt.DWORD),
                ("nAvgBytesPerSec", wt.DWORD), ("nBlockAlign", wt.WORD), ("wBitsPerSample", wt.WORD),
                ("cbSize", wt.WORD)]


class WAVEHDR(ctypes.Structure):
    pass


WAVEHDR._fields_ = [("lpData", ctypes.c_void_p), ("dwBufferLength", wt.DWORD), ("dwBytesRecorded", wt.DWORD),
                    ("dwUser", ctypes.c_size_t), ("dwFlags", wt.DWORD), ("dwLoops", wt.DWORD),
                    ("lpNext", ctypes.POINTER(WAVEHDR)), ("reserved", ctypes.c_size_t)]

WAVE_MAPPER = 0xFFFFFFFF
CALLBACK_EVENT = 0x50000
WHDR_DONE = 0x1
WAIT_TIMEOUT = 0x102

_winmm = ctypes.WinDLL("winmm")
_k32 = ctypes.WinDLL("kernel32")
_HWI = wt.HANDLE
_winmm.waveInOpen.argtypes = [ctypes.POINTER(_HWI), wt.UINT, ctypes.POINTER(WAVEFORMATEX), ctypes.c_size_t,
                              ctypes.c_size_t, wt.DWORD]
for _name in ("waveInPrepareHeader", "waveInUnprepareHeader", "waveInAddBuffer"):
    getattr(_winmm, _name).argtypes = [_HWI, ctypes.POINTER(WAVEHDR), wt.UINT]
for _name in ("waveInStart", "waveInStop", "waveInReset", "waveInClose"):
    getattr(_winmm, _name).argtypes = [_HWI]
_winmm.waveInGetNumDevs.restype = wt.UINT
_k32.CreateEventW.restype = wt.HANDLE
_k32.CreateEventW.argtypes = [ctypes.c_void_p, wt.BOOL, wt.BOOL, wt.LPCWSTR]
_k32.WaitForSingleObject.argtypes = [wt.HANDLE, wt.DWORD]
_k32.CloseHandle.argtypes = [wt.HANDLE]


def mic_count():
    try:
        return int(_winmm.waveInGetNumDevs())
    except Exception:
        return 0


class Mic:
    """Микрофон по умолчанию: read() отдаёт по 512 отсчётов (float32, −1…1)."""

    def __init__(self, buffers=24):
        self.n = buffers
        self.h = _HWI()
        self.event = None
        self.bufs, self.hdrs = [], []
        self.next = 0

    def open(self):
        import numpy as np  # noqa: F401 — проверка, что есть numpy
        fmt = WAVEFORMATEX(1, 1, RATE, RATE * 2, 2, 16, 0)
        self.event = _k32.CreateEventW(None, False, False, None)
        r = _winmm.waveInOpen(ctypes.byref(self.h), WAVE_MAPPER, ctypes.byref(fmt), self.event, 0, CALLBACK_EVENT)
        if r:
            _k32.CloseHandle(self.event)
            raise OSError(f"микрофон не открылся (код {r})")
        size = ctypes.sizeof(WAVEHDR)
        for _ in range(self.n):
            buf = ctypes.create_string_buffer(CHUNK * 2)
            hdr = WAVEHDR()
            hdr.lpData = ctypes.cast(buf, ctypes.c_void_p)
            hdr.dwBufferLength = CHUNK * 2
            self.bufs.append(buf)
            self.hdrs.append(hdr)
            _winmm.waveInPrepareHeader(self.h, ctypes.byref(hdr), size)
            _winmm.waveInAddBuffer(self.h, ctypes.byref(hdr), size)
        _winmm.waveInStart(self.h)
        return self

    def read(self, timeout=1.0):
        import numpy as np
        hdr = self.hdrs[self.next]
        end = time.time() + timeout
        while not hdr.dwFlags & WHDR_DONE:
            if time.time() > end:
                return None
            _k32.WaitForSingleObject(self.event, 50)
        data = np.frombuffer(ctypes.string_at(hdr.lpData, hdr.dwBytesRecorded), dtype=np.int16)
        data = data.astype(np.float32) / 32768.0
        hdr.dwFlags &= ~WHDR_DONE
        hdr.dwBytesRecorded = 0
        _winmm.waveInAddBuffer(self.h, ctypes.byref(hdr), ctypes.sizeof(WAVEHDR))
        self.next = (self.next + 1) % self.n
        if len(data) < CHUNK:
            data = np.pad(data, (0, CHUNK - len(data)))
        return data

    def close(self):
        if not self.h:
            return
        try:
            _winmm.waveInStop(self.h)
            _winmm.waveInReset(self.h)
            for hdr in self.hdrs:
                _winmm.waveInUnprepareHeader(self.h, ctypes.byref(hdr), ctypes.sizeof(WAVEHDR))
            _winmm.waveInClose(self.h)
        finally:
            if self.event:
                _k32.CloseHandle(self.event)
            self.h = _HWI()
            self.event = None


class FileMic:
    """Для проверок: вместо микрофона — запись (.npy, 16 кГц) в реальном времени, потом тишина.
    Включается переменной среды NOVA_VOICE_FAKE_MIC=путь."""

    def __init__(self, *a, **k):
        import numpy as np
        self.np = np
        self.audio = np.load(os.environ["NOVA_VOICE_FAKE_MIC"]).astype(np.float32)
        self.pos = 0
        self.t0 = 0.0

    def open(self):
        self.t0 = time.time()
        return self

    def read(self, timeout=1.0):
        due = self.t0 + self.pos / RATE
        if due > time.time():
            time.sleep(due - time.time())
        c = self.audio[self.pos:self.pos + CHUNK]
        self.pos += CHUNK
        return self.np.pad(c, (0, CHUNK - len(c)))

    def close(self):
        pass


if os.environ.get("NOVA_VOICE_FAKE_MIC"):
    Mic = FileMic  # noqa: F811


# =========================
# «КТО-ТО ГОВОРИТ?» — Silero VAD
# =========================

class Vad:
    def __init__(self):
        import numpy as np
        import onnxruntime as ort
        import faster_whisper.vad as fv
        path = os.path.join(os.path.dirname(fv.__file__), "assets", "silero_vad_v6.onnx")
        opts = ort.SessionOptions()
        opts.inter_op_num_threads = 1
        opts.intra_op_num_threads = 1
        opts.log_severity_level = 4
        self.np = np
        self.sess = ort.InferenceSession(path, providers=["CPUExecutionProvider"], sess_options=opts)
        self.reset()

    def reset(self):
        np = self.np
        self.h = np.zeros((1, 1, 128), dtype=np.float32)
        self.c = np.zeros((1, 1, 128), dtype=np.float32)
        self.ctx = np.zeros((1, 64), dtype=np.float32)

    def __call__(self, chunk):
        x = self.np.concatenate([self.ctx, chunk.reshape(1, -1)], axis=1).astype(self.np.float32)
        out, self.h, self.c = self.sess.run(None, {"input": x, "h": self.h, "c": self.c})
        self.ctx = x[:, -64:]
        return float(self.np.asarray(out).reshape(-1)[0])


# =========================
# WHISPER
# =========================

HALLUCINATIONS = re.compile(
    r"субтитр|продолжение следует|спасибо за просмотр|подписывайтесь|ставьте лайк|dimatorzok|"
    r"редактор|корректор|amara|до новых встреч|музыка\W*$|^\W*(?:аплодисменты|смех)\W*$", re.I)


def load_whisper():
    """(модель, "cuda"/"cpu"). Для видеокарты нужны библиотеки CUDA 12 — берём те, что принёс Ollama."""
    cuda_dir = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "lib", "ollama", "cuda_v12")
    if os.path.isdir(cuda_dir) and cuda_dir not in os.environ.get("PATH", ""):
        os.environ["PATH"] = cuda_dir + os.pathsep + os.environ.get("PATH", "")
        try:
            os.add_dll_directory(cuda_dir)
        except OSError:
            pass
    import numpy as np
    import ctranslate2
    from faster_whisper import WhisperModel
    probe = (np.sin(np.arange(RATE) / 9.0) * 0.02).astype(np.float32)
    if ctranslate2.get_cuda_device_count() > 0:
        try:
            m = WhisperModel(MODEL, device="cuda", compute_type="int8_float16")
            list(m.transcribe(probe, language="ru", beam_size=1)[0])  # библиотеки грузятся только тут
            return m, "cuda"
        except Exception as e:
            log(f"voice: Whisper на видеокарте не запустился, беру процессор: {e!r}")
    m = WhisperModel(MODEL, device="cpu", compute_type="int8", cpu_threads=4)
    return m, "cpu"


def transcribe(model, audio):
    segs, _ = model.transcribe(audio, language="ru", beam_size=3, initial_prompt=PROMPT, vad_filter=False,
                               condition_on_previous_text=False, without_timestamps=True, temperature=0.0)
    parts = []
    for s in segs:
        if s.no_speech_prob > 0.6 and s.avg_logprob < -0.7:
            continue  # скорее шум, чем речь
        if s.avg_logprob < -1.1:
            continue  # Whisper сам не уверен — не выдумываем
        parts.append(s.text.strip())
    text = " ".join(p for p in parts if p).strip()
    if not text or HALLUCINATIONS.search(text):
        return ""
    n = _norm(text)
    if len(n) > 20 and n in _norm(PROMPT):
        return ""  # повторил подсказку — так бывает на шуме
    return text


def _norm(s):
    return re.sub(r"[^\w ]+", "", str(s).lower().replace("ё", "е")).strip()


# =========================
# «НОВА, …» — разбор фразы
# =========================

WAKE_RE = re.compile(r"(?<![а-яёa-z])(нова|nova)(?![а-яёa-z])", re.I)
# «Снова открой дискорд» — так распознаётся «Нова, открой дискорд», если сказано слитно
SNOVA_RE = re.compile(r"^\s*снова[,\s]+(?=(?:открой|открыть|закрой|включи|выключи|поставь|сделай|запусти|найди|"
                      r"покажи|скажи|расскажи|какая|какой|какое|который|сколько|убавь|прибавь|громкость|таймер|"
                      r"напомни|привет|загугли)\b)", re.I)
FILLER_RE = re.compile(r"^(?:эй|хей|эй ты|окей|ок|слушай|ну|алло|а|о|так|привет)$", re.I)


def find_wake(text):
    """Команда после «Нова» (может быть пустой) или None, если NOVA не звали."""
    t = text.strip()
    m = SNOVA_RE.match(t)
    if m:
        return t[m.end():].strip(" ,.!?:;—-")
    m = WAKE_RE.search(t)
    if not m:
        return None
    after = t[m.end():].strip(" ,.!?:;—-«»\"")
    before = t[:m.start()].strip(" ,.!?:;—-«»\"")
    if FILLER_RE.match(before):
        before = "привет" if before.lower() == "привет" and not after else ""
    return after or before


STOP_RE = re.compile(r"^(?:стоп|хватит|замолчи|молчи|тихо|отмена|отмени|прекрати|ладно|неважно|ничего|забей)$")
OFF_RE = re.compile(r"^(?:выключись|отключись|перестань слушать|не слушай|выключи (?:режим помощника|прослушивание|"
                    r"помощника)|выйди из режима)$")
BYE_RE = re.compile(r"^(?:пока|пока пока|до свидания|до встречи|спокойной ночи|отбой|выход|выйди)$")
WINDOW_RE = re.compile(r"^(?:открой|покажи|разверни) (?:нову|nova|окно|окно новы|себя|чат)$")
YES_RE = re.compile(r"^(?:да|ага|угу|давай|конечно|закрывай|закрой|выключай|выполняй|делай|подтверждаю|ок|окей|"
                    r"можно|yes)(?:\s|$)")
NO_RE = re.compile(r"^(?:нет|не надо|не нужно|не|отмена|отмени|стоп|не закрывай|оставь|no)(?:\s|$)")
GREET_RE = re.compile(r"^(?:привет(?:ик|ствую)?|здравствуй(?:те)?|хай|хэй|хеллоу|hello|hi|салют|здорово|"
                      r"добрый (?:день|вечер)|доброе утро|доброй ночи|ку|йоу|прив)(?:\s|$)")
HOWRU_RE = re.compile(r"^(?:как (?:у тебя )?(?:дела|делишки)|как ты|как жизнь|как поживаешь|как сама|что нового)$")
WEEKDAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября",
          "ноября", "декабря"]


def plain_low(s):
    s = str(s or "").lower().replace("ё", "е")
    return re.sub(r"\s+", " ", re.sub(r"[.,!?;:«»\"“”…()]+", " ", s)).strip()


def local_answer(cmd, name=""):
    """Ответ без нейросети — мгновенно. dict(text=…, kind=…) или None."""
    c = plain_low(cmd)
    if not c or STOP_RE.match(c):
        return {"kind": "stop"}
    if OFF_RE.match(c):
        return {"kind": "off", "text": "Выключаю прослушивание. Включить снова — в окне NOVA, раздел «Режим помощника»."}
    if BYE_RE.match(c):
        return {"kind": "bye", "text": random.choice(["Пока! Если что — просто позови.", "До встречи! Я рядом."])}
    if WINDOW_RE.match(c):
        return {"kind": "window", "text": "Открываю окно NOVA."}
    g = GREET_RE.match(c)
    if g:
        rest = c[g.end():].strip()
        if rest and not HOWRU_RE.match(rest):  # «привет, открой ютуб» — приветствие отбрасываем
            words = len(g.group(0).split())
            return {"kind": "rewrite", "text": " ".join(cmd.strip().split()[words:]).lstrip(" ,.!?—-")}
        h = datetime.now().hour
        hi = ("Привет" if re.match(r"(привет|хай|хэй|хеллоу|hello|hi|салют|здорово|ку|йоу|прив)", c)
              else "Доброе утро" if 5 <= h < 12 else "Добрый день" if 12 <= h < 18
              else "Добрый вечер" if 18 <= h < 23 else "Доброй ночи")
        to = f", {name}" if name else ""
        if rest:
            return {"kind": "say", "text": f"{hi}{to}! У меня всё отлично, готова помогать. А у тебя как?"}
        return {"kind": "say", "text": f"{hi}{to}! " + random.choice(["Чем помочь?", "Я слушаю.", "Что сделаем?"])}
    if HOWRU_RE.match(c):
        return {"kind": "say", "text": random.choice(["Всё отлично, готова помогать! А у тебя как?",
                                                      "Отлично! Чем займёмся?"])}
    now = datetime.now()
    if re.search(r"(который час|сколько (?:сейчас )?времени|сколько время|какое (?:сейчас )?время)", c):
        return {"kind": "say", "text": f"Сейчас {now:%H:%M}."}
    if re.search(r"(какое (?:сегодня )?число|какой (?:сегодня )?день(?: недели)?|какая (?:сегодня )?дата|"
                 r"что (?:сегодня )?за день)", c):
        return {"kind": "say", "text": f"Сегодня {WEEKDAYS[now.weekday()]}, {now.day} {MONTHS[now.month - 1]}."}
    if re.match(r"(спасибо|спс|благодарю|пасиб|сенкс|thanks|thank you)", c):
        return {"kind": "say", "text": random.choice(["Обращайся!", "Всегда пожалуйста!", "Рада помочь!"])}
    if re.match(r"^(ты (тут|здесь)|ты меня слышишь|слышишь меня|ты слышишь)$", c):
        return {"kind": "say", "text": "Да, я тут!"}
    return None


# =========================
# ГОЛОС И ЗВУКИ
# =========================

EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿️‍⃣]")


def speech_text(text):
    """Markdown и эмодзи голос читает плохо («звёздочка», «улыбающееся лицо») — убираем."""
    t = str(text or "")
    t = re.sub(r"```.*?```", " ", t, flags=re.S)
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", t)
    t = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", t)
    t = re.sub(r"https?://\S+", "ссылка", t)
    t = re.sub(r"[*_`#>|~]+", "", t)
    t = EMOJI_RE.sub("", t)
    return re.sub(r"\s+", " ", t).strip()


# --- воспроизведение: waveOut (Windows), звук идёт кусками по мере готовности ---

_winmm.waveOutOpen.argtypes = [ctypes.POINTER(_HWI), wt.UINT, ctypes.POINTER(WAVEFORMATEX), ctypes.c_size_t,
                               ctypes.c_size_t, wt.DWORD]
for _name in ("waveOutPrepareHeader", "waveOutUnprepareHeader", "waveOutWrite"):
    getattr(_winmm, _name).argtypes = [_HWI, ctypes.POINTER(WAVEHDR), wt.UINT]
for _name in ("waveOutReset", "waveOutClose"):
    getattr(_winmm, _name).argtypes = [_HWI]


class Player:
    """Играет 16-битный моно-звук кусками: write() сразу ставит кусок в очередь колонок."""

    def __init__(self, rate):
        self.h = _HWI()
        self.event = _k32.CreateEventW(None, False, False, None)
        fmt = WAVEFORMATEX(1, 1, rate, rate * 2, 2, 16, 0)
        r = _winmm.waveOutOpen(ctypes.byref(self.h), WAVE_MAPPER, ctypes.byref(fmt), self.event, 0, CALLBACK_EVENT)
        if r:
            _k32.CloseHandle(self.event)
            raise OSError(f"колонки не открылись (код {r})")
        self.items = deque()
        self.silent = bool(os.environ.get("NOVA_VOICE_SILENT"))

    def write(self, pcm):
        if not pcm:
            return
        if self.silent:
            pcm = bytes(len(pcm))
        buf = ctypes.create_string_buffer(pcm, len(pcm))
        hdr = WAVEHDR()
        hdr.lpData = ctypes.cast(buf, ctypes.c_void_p)
        hdr.dwBufferLength = len(pcm)
        size = ctypes.sizeof(WAVEHDR)
        _winmm.waveOutPrepareHeader(self.h, ctypes.byref(hdr), size)
        _winmm.waveOutWrite(self.h, ctypes.byref(hdr), size)
        self.items.append((buf, hdr))
        self._reap()

    def _reap(self):
        while self.items and self.items[0][1].dwFlags & WHDR_DONE:
            _winmm.waveOutUnprepareHeader(self.h, ctypes.byref(self.items[0][1]), ctypes.sizeof(WAVEHDR))
            self.items.popleft()

    def drain(self, stopped):
        """Дождаться, пока всё отзвучит (или пока не перебили)."""
        while self.items and not stopped.is_set():
            self._reap()
            if self.items:
                _k32.WaitForSingleObject(self.event, 30)

    def close(self):
        _winmm.waveOutReset(self.h)  # перебили — замолчать сразу
        for _ in range(100):
            self._reap()
            if not self.items:
                break
            time.sleep(0.005)
        _winmm.waveOutClose(self.h)
        _k32.CloseHandle(self.event)


def _mp3_decoder(rate=24000):
    """Кусок mp3 → кусок PCM. Декодер помнит, на чём остановился, — можно кормить по мере прихода."""
    import av
    codec = av.CodecContext.create("mp3", "r")
    rs = av.AudioResampler(format="s16", layout="mono", rate=rate)

    def feed(data):
        out = []
        for pkt in codec.parse(data):
            for fr in codec.decode(pkt):
                for f in rs.resample(fr):
                    out.append(f.to_ndarray().tobytes())
        return b"".join(out)

    return feed


class Speaker:
    """Голос NOVA — нейронная Светлана (edge-tts): звук начинает играть, как только пришли первые кусочки.
    Сбой у Microsoft — пробуем ещё раз; голос Windows (Ирина) — только если совсем не вышло (нет интернета)."""

    def __init__(self, settings):
        self.settings = settings
        self.dir = tempfile.mkdtemp(prefix="nova-voice-")
        base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
        self.cache_dir = os.path.join(base, "NOVA", "voice-cache")  # частые фразы звучат сразу, даже после перезапуска
        os.makedirs(self.cache_dir, exist_ok=True)
        self.stopped = threading.Event()
        self.n = 0
        self.n_lock = threading.Lock()
        self.offline_until = 0.0  # Светлана не отвечала — какое-то время сразу говорим голосом Windows

    def _voice(self):
        v = str(self.settings.get("voice") or "")
        return "ru-RU-DmitryNeural" if re.search(r"dmitry|дмитрий|pavel|павел", v, re.I) else "ru-RU-SvetlanaNeural"

    def _rate(self):
        try:
            pct = round((float(self.settings.get("rate") or 1.05) - 1) * 100)
        except (TypeError, ValueError):
            pct = 5
        return f"{pct:+d}%"

    def _new_path(self, ext):
        with self.n_lock:
            self.n += 1
            return os.path.join(self.dir, f"s{self.n}.{ext}")

    def _cache_path(self, text):
        h = hashlib.sha1(f"{self._voice()}|{self._rate()}|{text}".encode("utf-8")).hexdigest()[:24]
        return os.path.join(self.cache_dir, f"{h}.mp3")

    def _save_cache(self, text, data):
        if not data or len(text) > 90:
            return
        try:
            with open(self._cache_path(text), "wb") as f:
                f.write(data)
            files = sorted((os.path.join(self.cache_dir, x) for x in os.listdir(self.cache_dir)), key=os.path.getmtime)
            for old in files[:-400]:
                os.remove(old)
        except OSError:
            pass

    async def _edge(self, text, on_audio):
        """Потоково получить речь у edge-tts. True — пришла целиком."""
        import edge_tts
        comm = edge_tts.Communicate(text, self._voice(), rate=self._rate(), connect_timeout=5, receive_timeout=10)
        it = comm.stream().__aiter__()
        first = True
        try:
            while not self.stopped.is_set():
                try:
                    msg = await asyncio.wait_for(it.__anext__(), 4.0 if first else 10.0)
                except StopAsyncIteration:
                    return True
                if msg.get("type") == "audio" and msg.get("data"):
                    first = False
                    on_audio(msg["data"])
            return False
        finally:
            try:
                await asyncio.wait_for(it.aclose(), 2)  # перебили — аккуратно закрыть соединение с Microsoft
            except Exception:
                pass

    def _say_edge(self, text):
        """Сказать Светланой. False — если не пришло ни кусочка (тогда пробуем ещё раз или голос Windows)."""
        state = {"player": None, "data": bytearray()}
        feed = _mp3_decoder()

        def on_audio(data):
            state["data"] += data
            pcm = feed(data)
            if pcm:
                if state["player"] is None:
                    state["player"] = Player(24000)
                state["player"].write(pcm)

        complete = False
        try:
            complete = asyncio.run(self._edge(text, on_audio))
        except Exception as e:
            if state["player"] is None:
                log(f"voice: edge-tts {type(e).__name__}: {e}")
        player = state["player"]
        if player is None:
            return False
        try:
            player.drain(self.stopped)
        finally:
            player.close()
        if complete and not self.stopped.is_set():
            self._save_cache(text, bytes(state["data"]))
        return True

    def _play_file(self, path):
        try:
            if path.endswith(".wav"):
                with wave.open(path, "rb") as w:
                    player = Player(w.getframerate())
                    try:
                        while not self.stopped.is_set():
                            data = w.readframes(4096)
                            if not data:
                                break
                            player.write(data)
                        player.drain(self.stopped)
                    finally:
                        player.close()
                return True
            feed = _mp3_decoder()
            with open(path, "rb") as f:
                data = f.read()
            player = Player(24000)
            try:
                player.write(feed(data))
                player.drain(self.stopped)
            finally:
                player.close()
            os.utime(path)  # свежая — не удалится из кэша первой
            return True
        except Exception as e:
            log(f"voice: воспроизведение {e!r}")
            return False

    def say(self, text):
        """Сказать вслух. False — если перебили."""
        self.stopped.clear()
        t = speech_text(text)
        if not t:
            return True
        cached = self._cache_path(t)
        if os.path.exists(cached) and self._play_file(cached):
            return not self.stopped.is_set()
        if time.time() > self.offline_until:
            for _ in range(2):  # у Microsoft бывают разовые сбои — со второго раза обычно выходит
                if self.stopped.is_set() or self._say_edge(t):
                    return not self.stopped.is_set()
            self.offline_until = time.time() + 45
            log("voice: Светлана (edge-tts) не отвечает — какое-то время говорю голосом Windows")
        path = self._sapi(t)
        if path:
            self._play_file(path)
        return not self.stopped.is_set()

    def warm(self, phrases):
        """Заранее озвучить частые фразы (в фоне, один раз — дальше они лежат в кэше)."""
        for t in phrases:
            if os.path.exists(self._cache_path(t)):
                continue
            data = bytearray()
            try:
                if asyncio.run(self._edge(t, data.extend)):
                    self._save_cache(t, bytes(data))
            except Exception:
                pass
            time.sleep(0.3)

    def _sapi(self, text):
        """Голос Windows (Ирина) — без интернета. Через PowerShell: System.Speech есть в любой Windows 10/11."""
        wav = self._new_path("wav")
        script = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -eq 'ru-RU' } | "
                  "Select-Object -First 1; if ($v) { $s.SelectVoice($v.VoiceInfo.Name) }; $s.Rate = 1; "
                  "$s.SetOutputToWaveFile($env:NOVA_WAV); $s.Speak($env:NOVA_TEXT); $s.Dispose()")
        try:
            subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], timeout=20,
                           env=dict(os.environ, NOVA_WAV=wav, NOVA_TEXT=text), capture_output=True,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            return wav if os.path.exists(wav) and os.path.getsize(wav) > 1000 else None
        except Exception as e:
            log(f"voice: голос Windows не сработал: {e!r}")
            return None

    def stop(self):
        self.stopped.set()


WARM_PHRASES = [
    "Привет! Чем помочь?", "Привет! Я слушаю.", "Привет! Что сделаем?", "Доброе утро! Чем помочь?",
    "Добрый день! Чем помочь?", "Добрый вечер! Чем помочь?", "Готово.", "Хорошо, не буду.", "Обращайся!",
    "Всегда пожалуйста!", "Рада помочь!", "Да, я тут!", "Отлично! Чем займёмся?",
    "Всё отлично, готова помогать! А у тебя как?", "Пока! Если что — просто позови.", "До встречи! Я рядом.",
    "Открываю окно NOVA.", "Открываю YouTube.", "Открываю Discord.", "Секунду, я ещё отвечаю в окне NOVA.",
]


def _tone_wav(notes, volume=0.22):
    import numpy as np
    out = []
    for i, f in enumerate(notes):
        n = int(RATE * 0.16)
        t = np.arange(n) / RATE
        env = np.minimum(1, t / 0.012) * np.exp(-t * 18)
        out.append(np.sin(2 * math.pi * f * t) * env)
        if i < len(notes) - 1:
            out.append(np.zeros(int(RATE * 0.01)))
    data = (np.concatenate(out) * volume * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(data.tobytes())
    return buf.getvalue()


_TONES = {}


def chime(kind="wake"):
    """Короткий звук: «услышала имя», «включилась», «выключилась»."""
    if os.environ.get("NOVA_VOICE_SILENT"):
        return
    notes = {"wake": [740, 1110], "on": [520, 780, 1040], "off": [780, 520], "soft": [880], "error": [330, 262]}
    try:
        import winsound
        if kind not in _TONES:
            _TONES[kind] = _tone_wav(notes.get(kind, [880]), 0.12 if kind == "soft" else 0.2)
        threading.Thread(target=winsound.PlaySound, args=(_TONES[kind], winsound.SND_MEMORY), daemon=True).start()
    except Exception as e:
        log(f"voice: chime {e!r}")


# =========================
# ОКОШКО В УГЛУ ЭКРАНА (когда окно NOVA закрыто)
# =========================

class Bubble:
    """Отдельный процесс nova_bubble.pyw: маленькая плашка «NOVA слушает…» справа внизу, поверх всех окон."""

    def __init__(self, on_click):
        self.proc = None
        self.on_click = on_click
        self.lock = threading.Lock()

    def send(self, **msg):
        if os.environ.get("NOVA_VOICE_NO_BUBBLE"):
            return
        with self.lock:
            if not self.proc or self.proc.poll() is not None:
                if msg.get("hide"):
                    return
                exe = sys.executable
                if exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
                    exe = exe[:-10] + "pythonw.exe"
                try:
                    self.proc = subprocess.Popen([exe, os.path.join(APP_DIR, "nova_bubble.pyw")],
                                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
                                                 encoding="utf-8", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                    threading.Thread(target=self._read, args=(self.proc,), daemon=True).start()
                except OSError as e:
                    log(f"voice: bubble {e!r}")
                    self.proc = None
                    return
            try:
                self.proc.stdin.write(json.dumps(msg) + "\n")  # только ASCII: у pythonw своя кодировка stdin
                self.proc.stdin.flush()
            except OSError:
                self.proc = None

    def _read(self, proc):
        for line in proc.stdout:
            if line.strip() == "open":
                try:
                    self.on_click()
                except Exception as e:
                    log(f"voice: bubble click {e!r}")

    def close(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.stdin.write('{"quit": true}\n')
                    self.proc.stdin.flush()
                except OSError:
                    pass
            self.proc = None


# =========================
# ДВИЖОК
# =========================

def available():
    """(можно ли включить, почему нет)."""
    try:
        import numpy  # noqa: F401
        import onnxruntime  # noqa: F401
        import faster_whisper  # noqa: F401
    except ImportError as e:
        return False, f"не установлена библиотека {e.name} — нужен faster-whisper (py -m pip install faster-whisper)"
    if not mic_count():
        return False, "не нашла микрофон"
    return True, ""


class Engine:
    AWAKE_SEC = 8

    def __init__(self, ask, confirm, open_window, turn_off, settings):
        self.ask, self.confirm_cb, self.open_window, self.turn_off = ask, confirm, open_window, turn_off
        self.settings = settings
        self.speaker = Speaker(settings)
        self.bubble = Bubble(self._open_window)
        self.running = False
        self.state = "off"   # off, loading, idle, awake, thinking, speaking, confirm, error
        self.problem = ""
        self.device = ""
        self.heard = ""
        self.said = ""
        self.level = 0.0
        self.log = deque(maxlen=40)
        self.rev = 0          # растёт, когда меняется что-то для окна
        self.chat_rev = 0     # растёт, когда в чат добавились сообщения
        self.awake_until = 0.0
        self.awake_for = self.AWAKE_SEC
        self.confirm_id = None
        self.speak_until = 0.0  # что микрофон слышит, пока NOVA говорит, — это эхо
        self.talking = False    # прямо сейчас кто-то говорит (ожидание «без имени» не обрывается)
        self.cut = threading.Event()  # NOVA договорила — начатый кусок (её эхо) выбросить, слушать заново
        self.awake_end = 0.0    # когда закончилось последнее ожидание «без имени»
        self.viewer_at = 0.0    # когда окно NOVA последний раз смотрело на помощника
        self.model = None
        self.segments = queue.Queue(maxsize=8)
        self.jobs = queue.Queue()
        self.busy = False
        self.cancel = threading.Event()
        self._threads = []
        self._lock = threading.Lock()
        self._hide_at = 0.0
        self.gen = 0

    def _alive(self, g):
        return self.running and self.gen == g

    # --- снаружи ---

    def start(self):
        with self._lock:
            if self.running:
                return
            self.running = True
            self.gen += 1  # прежние потоки (если выключили и сразу включили) увидят это и закончат
            self.cancel.clear()
            for q in (self.segments, self.jobs):
                while not q.empty():
                    q.get_nowait()
            self._set("loading" if self.model is None else "idle")
            g = self.gen
            self._threads = [threading.Thread(target=f, args=(g,), daemon=True, name=n) for f, n in
                             ((self._listen, "voice-mic"), (self._recognize, "voice-asr"), (self._respond, "voice-do"))]
            for t in self._threads:
                t.start()

    def stop(self):
        with self._lock:
            if not self.running:
                return
            self.running = False
            self.cancel.set()
            self.speaker.stop()
            self.jobs.put(None)
            self.speak_until = 0.0
            self._set("off")
            self.bubble.close()

    def snapshot(self, viewer=False):
        if viewer:
            self.viewer_at = time.time()
        return {"state": self.state, "running": self.running, "problem": self.problem, "device": self.device,
                "heard": self.heard, "said": self.said, "level": round(self.level, 3), "rev": self.rev,
                "chat_rev": self.chat_rev, "log": list(self.log)[-10:],
                "awake_left": max(0.0, self.awake_until - time.time()) if self.state in ("awake", "confirm") else 0,
                "awake_for": self.awake_for}

    def tap(self):
        """Нажали на шар в окне: перебить, если говорит; иначе — слушать без «Нова»."""
        if self.state in ("speaking", "thinking"):
            self._interrupt()
        elif self.state in ("idle", "awake"):
            self._wake(sound="wake")

    def say_command(self, text):
        """Подсказка в окне («Нова, открой ютуб») — как будто это сказали вслух."""
        if self.running and not self.busy and text.strip():
            self._chime("wake")
            self.jobs.put(("cmd", text.strip()))

    # --- состояние ---

    def _set(self, state, heard=None, said=None):
        self.state = state
        if heard is not None:
            self.heard = heard
        if said is not None:
            self.said = said
        self.rev += 1
        self._show_bubble()

    def _add_log(self, who, text):
        t = speech_text(text)
        if t:
            self.log.append({"who": who, "text": t[:217] + "…" if len(t) > 220 else t, "t": time.time()})
            self.rev += 1

    def _show_bubble(self):
        """Плашка в углу — только если окно NOVA не показывает помощника."""
        if time.time() - self.viewer_at < 1.5 or not self.running:
            self.bubble.send(hide=True)
            return
        titles = {"awake": "Слушаю…", "thinking": "Думаю…", "speaking": "говорит", "confirm": "Скажи «да» или «нет»"}
        if self.state in titles:
            text = self.said if self.state in ("speaking", "confirm") else self.heard
            self.bubble.send(show=True, state=self.state, title=titles[self.state], text=text)
            self._hide_at = 0
        elif self.state == "error":
            self.bubble.send(show=True, state="error", title="Помощник не слышит", text=self.problem)
        else:
            self.bubble.send(hide=True, delay=2.5)

    def _chime(self, kind):
        self.speak_until = max(self.speak_until, time.time() + 0.25)  # свой звук микрофон тоже слышит
        chime(kind)

    def _wake(self, sec=AWAKE_SEC, sound="wake"):
        if sound:
            self._chime(sound)
        self.awake_for = sec
        self.awake_until = time.time() + sec
        self.awake_end = 0.0
        self._set("awake", heard="")

    def _interrupt(self):
        self.cancel.set()
        self.speaker.stop()
        self._chime("off")
        self._set("idle")

    # --- поток 1: микрофон → куски речи ---

    def _listen(self, g):
        import numpy as np
        try:
            vad = Vad()
        except Exception as e:
            log(f"voice: VAD {e!r}")
            self.problem = "Не получилось запустить распознавание речи (VAD)."
            return self._set("error")
        mic = None
        while self._alive(g):
            try:
                mic = Mic().open()
            except Exception as e:
                self.problem = f"Нет доступа к микрофону: {e}. Проверь, что он подключён и разрешён в Windows."
                self._set("error")
                for _ in range(50):
                    if not self._alive(g):
                        return
                    time.sleep(0.1)
                continue
            if self.state == "error":
                self.problem = ""
                self._set("loading" if self.model is None else "idle")
            pre = deque(maxlen=10)       # 0,3 с до начала речи
            cur, talking, quiet, voiced, began = [], False, 0, 0, 0.0
            try:
                while self._alive(g):
                    chunk = mic.read()
                    if chunk is None:
                        raise OSError("микрофон перестал отдавать звук")
                    rms = float(np.sqrt(np.mean(chunk * chunk)))
                    self.level += (min(1.0, rms * 12) - self.level) * 0.5
                    p = vad(chunk)
                    if self.cut.is_set():
                        self.cut.clear()
                        if talking:  # это был её собственный голос из колонок
                            talking, cur, pre = False, [], deque(maxlen=10)
                            vad.reset()
                            continue
                    self.talking = talking
                    if not talking:
                        pre.append(chunk)
                        if p >= 0.5:
                            talking, cur, quiet, voiced, began = True, list(pre), 0, 1, time.time()
                        continue
                    cur.append(chunk)
                    if p >= 0.5:
                        voiced += 1
                        quiet = 0
                    elif p < 0.35:
                        quiet += 1
                    if quiet >= 22 or len(cur) >= 470:  # 0,7 с тишины или 15 с речи
                        if voiced >= 6:
                            audio = np.concatenate(cur)
                            try:
                                self.segments.put_nowait((audio, began, time.time()))
                            except queue.Full:
                                pass  # не успеваем распознавать — пропускаем
                        talking, cur, pre = False, [], deque(maxlen=10)
                        vad.reset()
            except Exception as e:
                log(f"voice: микрофон {e!r}")
            finally:
                mic.close()
            time.sleep(0.5)

    # --- поток 2: распознавание ---

    def _recognize(self, g):
        if self.model is None:
            try:
                self.model, self.device = load_whisper()
            except Exception as e:
                log(f"voice: Whisper {e!r}")
                self.problem = f"Не получилось загрузить распознавание речи (Whisper): {e}"
                return self._set("error")
        if not self._alive(g):
            return
        if self.state == "loading":
            self._set("idle")
        self._chime("on")
        threading.Thread(target=self.speaker.warm, args=(WARM_PHRASES,), daemon=True).start()
        while self._alive(g):
            try:
                audio, began, ended = self.segments.get(timeout=0.5)
            except queue.Empty:
                self._tick()
                continue
            try:
                text = transcribe(self.model, audio)
            except Exception as e:
                log(f"voice: распознавание {e!r}")
                continue
            self._tick()
            if text:
                self._heard(text, began)

    def _tick(self):
        if self.state in ("awake", "confirm") and time.time() > self.awake_until and not self.talking:
            self.awake_end = self.awake_until
            if self.state == "confirm":
                self.confirm_id = None
                self._add_log("nova", "Не услышала ответ — кнопка осталась в чате.")
            self._set("idle", heard="")

    def _heard(self, text, began):
        wake = find_wake(text)
        echo = began < self.speak_until + 0.05
        if self.busy or echo:
            # пока NOVA думает или говорит — только «Нова, стоп» (своё имя со «стоп» она сама не скажет)
            if wake is not None and (not wake or STOP_RE.match(plain_low(wake))) and self.busy:
                self._interrupt()
            return
        st = self.state
        if st == "idle" and wake is None and began <= self.awake_end:
            st = "awake"  # начал говорить, пока NOVA ещё ждала команду, — это ей
        if st in ("idle", "error", "loading"):
            if wake is None:
                return  # без «Нова» — не к ней
            if not wake:
                return self._wake(sound="wake")
            self._chime("wake")
            self.awake_end = 0.0
            return self.jobs.put(("cmd", wake))
        if st in ("awake", "confirm"):
            cmd = wake if wake is not None else text
            if st == "confirm":
                return self.jobs.put(("confirm", cmd, wake is not None))
            if not cmd:
                return self._wake(sound="soft")
            self.awake_end = 0.0
            self._set("thinking", heard=cmd)
            self.jobs.put(("cmd", cmd))

    # --- поток 3: выполнить и ответить ---

    def _respond(self, g):
        while self._alive(g):
            job = self.jobs.get()
            if job is None or not self._alive(g):
                break
            kind, text = job[0], job[1]
            self.busy = True
            self.cancel.clear()
            try:
                if kind == "confirm":
                    self._do_confirm(text, job[2] if len(job) > 2 else False)
                else:
                    self._do(text)
            except Exception as e:
                log(f"voice: ответ {e!r}")
                self._say("Что-то пошло не так. Попробуй ещё раз.")
                self._set("idle")
            finally:
                self.busy = False

    def _say(self, text, log_it=True):
        if log_it:
            self._add_log("nova", text)
        self._set("speaking", said=speech_text(text))
        self.speak_until = time.time() + 600
        try:
            self.speaker.say(text)
        finally:
            self.speak_until = time.time()
            self.cut.set()

    def _after(self, text):
        if not self.running:
            return
        if self.cancel.is_set():
            return self._set("idle")
        if speech_text(text).rstrip().endswith("?"):  # NOVA спросила — можно ответить без «Нова»
            self._wake(7, sound="soft")
        else:
            self._set("idle", heard="")

    def _do(self, cmd):
        cmd = cmd.strip(" ,.!?—-")
        local = local_answer(cmd, (self.settings.get("name") or "").strip())
        if local and local["kind"] == "rewrite":
            cmd, local = local["text"], None
        self._add_log("you", cmd)
        self._set("thinking", heard=cmd, said="")
        if local:
            k = local["kind"]
            if k == "stop":
                return self._set("idle")
            if k == "window":
                self._open_window()
            self._say(local["text"])
            if k == "off":
                threading.Thread(target=self.turn_off, daemon=True).start()
                return
            if k == "bye" and not self.settings.get("voice_bg"):
                threading.Thread(target=self.stop, daemon=True).start()  # «в фоне» не включено — выключиться
                return
            return self._after(local["text"])
        answer, actions = self.ask(cmd)
        if self.cancel.is_set() or not self.running:
            return self._set("idle")
        self.chat_rev += 1
        pending = [a for a in actions or [] if a.get("state", "pending") == "pending"]
        if pending:  # «закрой хром» — переспросить голосом вместо кнопки
            a = pending[0]
            self.confirm_id = a["id"]
            self._say(f"{a['label']}?")
            if self.running and self.confirm_id and not self.cancel.is_set():
                self.awake_for = 12
                self.awake_until = time.time() + 12
                self._set("confirm")
            return
        self._say(answer or "Готово.")
        self._after(answer)

    def _do_confirm(self, cmd, named=False):
        c = plain_low(cmd)
        short = len(c.split()) <= 4  # «да», «да, закрой» — а «да я вчера играл…» — это не ответ NOVA
        yes = short and bool(YES_RE.match(c))
        no = short and not yes and bool(NO_RE.match(c))
        if not (yes or no):
            if named and cmd.strip():  # «Нова, открой ютуб» вместо ответа — новая команда
                self.confirm_id = None
                return self._do(cmd)
            return  # посторонний разговор — ждём «да» или «нет» дальше
        aid, self.confirm_id = self.confirm_id, None
        if not aid:
            return self._set("idle")
        self._add_log("you", cmd)
        self._set("thinking", heard=cmd, said="")
        ok, text = self.confirm_cb(aid, yes)
        self.chat_rev += 1
        self._say((text or "Готово.") if yes and ok else ("Не получилось. " + (text or "")) if yes else "Хорошо, не буду.")
        self._after("")

    def _open_window(self):
        threading.Thread(target=self.open_window, daemon=True).start()
