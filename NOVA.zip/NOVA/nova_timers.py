"""NOVA — таймеры и напоминания.

Хранятся в nova_reminders.json (переживают перезапуск NOVA). Срабатывают, пока работает NOVA, — даже если
её окно закрыто: сервер дождётся последнего таймера. Когда время пришло — окошко поверх всех окон со звуком
(nova_alarm.pyw) с кнопками «Готово» и «Ещё 5 минут». Пропущенные (компьютер был выключен) показываются
при следующем запуске.
"""

import json
import os
import re
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta

APP_DIR = os.path.dirname(os.path.abspath(__file__))
_state = {"dir": APP_DIR, "started": False}
_lock = threading.Lock()
_items = []    # [{"id", "at" (секунды с 1970), "text", "created"}]
_rang = []     # недавно сработавшие — окно покажет их у себя: [{"id", "text", "at"}]


def log(text):  # nova_core подставит свой журнал ошибок
    pass


def _file():
    return os.path.join(_state["dir"], "nova_reminders.json")


def _save():
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(_items, f, ensure_ascii=False, indent=1)
    except OSError as e:
        log(f"timers save: {e!r}")


def start(data_dir=None):
    """Загрузить таймеры с диска и запустить часы (один раз)."""
    if data_dir:
        _state["dir"] = data_dir
    with _lock:
        _items.clear()
        try:
            with open(_file(), encoding="utf-8") as f:
                _items.extend(x for x in json.load(f) if isinstance(x, dict) and x.get("at"))
        except (OSError, ValueError):
            pass
    if not _state["started"]:
        _state["started"] = True
        threading.Thread(target=_clock, daemon=True).start()


# =========================
# Когда: «5 минут», «1 час 30 минут», «в 18:30», «завтра в 9:00»
# =========================

UNITS = [
    (r"час(?:а|ов)?|ч", 3600),
    (r"минут(?:а|у|ы)?|мин|м", 60),
    (r"секунд(?:а|у|ы)?|сек|с", 1),
]
NUM_WORDS = {"одну": 1, "один": 1, "одна": 1, "две": 2, "два": 2, "три": 3, "четыре": 4, "пять": 5, "шесть": 6,
             "семь": 7, "восемь": 8, "девять": 9, "десять": 10, "пятнадцать": 15, "двадцать": 20,
             "тридцать": 30, "сорок": 40, "пятьдесят": 50}
DUR_RE = re.compile(r"(?<!\w)(\d+(?:[.,]\d+)?|" + "|".join(NUM_WORDS) + r")?\s*(" + "|".join(u for u, _ in UNITS) + r")\b")


def parse_when(text, now=None):
    """Секунды с 1970, когда сработать, или None, если не поняли."""
    now = now or time.time()
    s = str(text or "").lower().replace("ё", "е").strip(" .!")
    s = re.sub(r"^(через|на|в течение)\s+", "", s)
    if s in ("полчаса", "пол часа"):
        return now + 1800
    if s in ("полторы минуты",):
        return now + 90
    if s in ("полтора часа",):
        return now + 5400
    # время на часах: «18:30», «в 9.05», «завтра в 9:00», «в 7 вечера»
    m = re.search(r"(завтра\s+)?(?:в\s+)?(\d{1,2})(?:[:.](\d{2}))?\s*(утра|дня|вечера|ночи)?$", s)
    if m and (m.group(3) or m.group(4) or s.startswith(("в ", "завтра"))):
        h, mi = int(m.group(2)), int(m.group(3) or 0)
        if m.group(4) in ("дня", "вечера") and h < 12:
            h += 12
        if m.group(4) == "ночи" and h == 12:
            h = 0
        if h > 23 or mi > 59:
            return None
        base = datetime.fromtimestamp(now)
        at = base.replace(hour=h, minute=mi, second=0, microsecond=0)
        if m.group(1):
            at += timedelta(days=1)
        elif at.timestamp() <= now + 5:
            at += timedelta(days=1)  # это время сегодня уже прошло — значит, завтра
        return at.timestamp()
    # длительность: «5 минут», «1 час 30 минут», «90 сек», «минуту»
    total, found = 0.0, False
    for num, unit in DUR_RE.findall(s):
        mult = next(sec for u, sec in UNITS if re.fullmatch(u, unit))
        n = NUM_WORDS.get(num) if num in NUM_WORDS else float(num.replace(",", ".")) if num else 1
        total += n * mult
        found = True
    if found and total > 0:
        return now + total
    if re.fullmatch(r"\d+(?:[.,]\d+)?", s):  # просто число — минуты
        return now + float(s.replace(",", ".")) * 60
    return None


def _say_in(sec):
    sec = int(round(sec))
    if sec < 60:
        return f"{sec} сек"
    h, rest = divmod(sec, 3600)
    m, s = divmod(rest, 60)
    parts = ([f"{h} ч"] if h else []) + ([f"{m} мин"] if m else []) + ([f"{s} сек"] if s and not h else [])
    return " ".join(parts)


def _clock_time(at):
    """«в 18:30», «завтра в 09:00», «23.11 в 09:00»."""
    d = datetime.fromtimestamp(at)
    day = "" if d.date() == datetime.now().date() else ("завтра " if d.date() == (datetime.now() + timedelta(days=1)).date()
                                                        else d.strftime("%d.%m "))
    return day + "в " + d.strftime("%H:%M" + (":%S" if at - time.time() < 120 else ""))


# =========================
# Список
# =========================

def add(at, text=""):
    item = {"id": uuid.uuid4().hex[:10], "at": round(at, 1), "text": str(text or "").strip()[:200],
            "created": round(time.time(), 1)}
    with _lock:
        _items.append(item)
        _items.sort(key=lambda x: x["at"])
        _save()
    return item


def upcoming():
    with _lock:
        return [dict(x) for x in sorted(_items, key=lambda x: x["at"])]


def has_pending():
    with _lock:
        return bool(_items)


def cancel(query=""):
    """Отменить: по номеру, по части текста или все («все», пусто). Возвращает отменённые."""
    q = str(query or "").lower().strip()
    with _lock:
        if not _items:
            return []
        if q in ("", "все", "всё", "all", "все таймеры", "все напоминания"):
            gone = list(_items)
        elif any(x["id"] == q for x in _items):
            gone = [x for x in _items if x["id"] == q]
        elif q.isdigit() and 1 <= int(q) <= len(_items):
            gone = [sorted(_items, key=lambda x: x["at"])[int(q) - 1]]
        else:
            q = re.sub(r"^(таймер|напоминание|про|о|об)\s+", "", q)
            # «духовка» найдёт «Выключить духовку»: сравниваем начала слов
            stems = [w[:max(4, len(w) - 2)] for w in re.findall(r"\w{3,}", q)]
            gone = [x for x in _items if stems and all(st in x["text"].lower().replace("ё", "е") for st in stems)]
            if not gone and q in ("таймер", "напоминание") and len(_items) == 1:
                gone = list(_items)
        for x in gone:
            _items.remove(x)
        _save()
        return gone


def take_rang(since=0):
    with _lock:
        return [dict(x) for x in _rang if x["at"] > since]


# =========================
# Часы и окошко со звуком
# =========================

def _clock():
    while True:
        try:
            now = time.time()
            with _lock:
                due = [x for x in _items if x["at"] <= now]
                for x in due:
                    _items.remove(x)
                if due:
                    _save()
            for x in due:
                _ring(x, late=now - x["at"] > 90)  # опоздали больше чем на полторы минуты — NOVA была выключена
        except Exception as e:
            log(f"timers clock: {e!r}")
        time.sleep(1)


def _ring(item, late=False):
    text = item["text"] or "Время вышло!"
    title = "Напоминание" if item["text"] else "Таймер"
    if late:
        title += " (пропущено, было на " + datetime.fromtimestamp(item["at"]).strftime("%d.%m %H:%M") + ")"
    with _lock:
        _rang.append({"id": item["id"], "text": text, "title": title, "at": time.time()})
        del _rang[:-20]
    threading.Thread(target=_popup, args=(item, title, text), daemon=True).start()


def _popup(item, title, text):
    exe = sys.executable
    w = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.path.exists(w):
        exe = w  # без чёрного окна консоли
    try:
        p = subprocess.Popen([exe, os.path.join(APP_DIR, "nova_alarm.pyw"), title, text],
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if p.wait() == 5:  # «Ещё 5 минут»
            add(time.time() + 300, item["text"])
    except Exception as e:
        log(f"timers popup: {e!r}")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, text, "NOVA — " + title, 0x40 | 0x40000 | 0x1000)
        except Exception:
            pass


# =========================
# Инструменты для нейросетей
# =========================

def set_timer(when: str, text: str) -> dict:
    """Поставить таймер или напоминание. Когда время придёт, NOVA покажет окошко поверх всех окон со звуком —
    даже если её окно закрыто (пока компьютер включён). Обязательно вызывай, когда просят «напомни…», «таймер на…».

    Args:
        when: через сколько или во сколько: «5 минут», «1 час 30 минут», «30 секунд», «в 18:30», «завтра в 9:00»
        text: о чём напомнить, коротко (пустая строка — просто таймер)
    """
    at = parse_when(when)
    if at is None:
        return {"error": f"Не поняла время «{when}». Примеры: «5 минут», «1 час 30 минут», «в 18:30», «завтра в 9:00»."}
    if at - time.time() > 7 * 86400:
        return {"error": "Напоминания — не дальше чем на неделю вперёд."}
    item = add(at, text)
    return {"ok": True, "rings_at": _clock_time(at), "in": _say_in(at - time.time()), "text": item["text"]}


def list_timers(name: str) -> dict:
    """Какие таймеры и напоминания сейчас поставлены.

    Args:
        name: часть текста, чтобы найти одно (пустая строка — показать все)
    """
    items = upcoming()
    q = str(name or "").lower().strip()
    if q:
        items = [x for x in items if q in x["text"].lower()]
    if not items:
        return {"timers": [], "note": "Таймеров и напоминаний нет."}
    return {"timers": [{"n": i + 1, "text": x["text"] or "таймер", "rings_at": _clock_time(x["at"]),
                        "left": _say_in(x["at"] - time.time())} for i, x in enumerate(items)]}


def cancel_timer(which: str) -> dict:
    """Отменить таймер или напоминание.

    Args:
        which: о чём оно (часть текста), его номер из списка или «все»
    """
    gone = cancel(which)
    if not gone:
        return {"error": "Не нашла такого таймера.", "now": list_timers("")["timers"]}
    return {"ok": True, "cancelled": [x["text"] or "таймер" for x in gone]}


TOOLS = [set_timer, list_timers, cancel_timer]


# =========================
# Быстрые команды без нейросети
# =========================

DUR = r"(?:\d+(?:[.,]\d+)?|" + "|".join(NUM_WORDS) + r")?\s*(?:" + "|".join(u for u, _ in UNITS) + r")"
WHEN_RE = (r"(?:через\s+(?:полчаса|полтора\s+часа|" + DUR + r"(?:\s+(?:и\s+)?" + DUR + r")*)"
           r"|(?:завтра\s+)?в\s+\d{1,2}(?:[:.]\d{2})?(?:\s*(?:утра|дня|вечера|ночи))?)")


def quick_command(text):
    t = " ".join(str(text or "").lower().replace("ё", "е").split()).strip(" .!")
    m = re.fullmatch(r"(?:поставь\s+|заведи\s+|включи\s+|запусти\s+)?таймер\s+(?:на\s+)?(.+)", t)
    if m:
        at = parse_when(m.group(1))
        if at is None:
            return None
        add(at, "")
        return f"⏰ Таймер на **{_say_in(at - time.time())}** — сработает {_clock_time(at)}."
    m = re.fullmatch(r"напомни(?:\s+мне)?\s+(" + WHEN_RE + r")\s+(.+)", t) or \
        re.fullmatch(r"напомни(?:\s+мне)?\s+(.+?)\s+(" + WHEN_RE + r")", t)
    if m:
        when, what = (m.group(1), m.group(2)) if re.match(r"через|завтра|в\s+\d", m.group(1)) else (m.group(2), m.group(1))
        at = parse_when(when)
        if at is None or at - time.time() > 7 * 86400:
            return None
        what = re.sub(r"^(?:что(?:бы)?|что нужно)\s+", "", what).strip()
        item = add(at, what[:1].upper() + what[1:])
        return f"🔔 Напомню **{_clock_time(at)}**: {item['text']}"
    if t in ("какие таймеры", "мои таймеры", "какие напоминания", "мои напоминания", "покажи таймеры",
             "покажи напоминания", "список таймеров", "сколько осталось"):
        items = upcoming()
        if not items:
            return "Таймеров и напоминаний нет."
        return "\n".join(f"- **{_clock_time(x['at'])}** (через {_say_in(x['at'] - time.time())}) — "
                         f"{x['text'] or 'таймер'}" for x in items)
    m = re.fullmatch(r"(?:отмени|убери|удали|выключи|останови|сбрось)\s+(все\s+)?(таймер(?:ы)?|напоминани(?:е|я))(?:\s+(.+))?", t)
    if m:
        gone = cancel("все" if m.group(1) else (m.group(3) or m.group(2)))
        if not gone:
            return None if upcoming() else "Таймеров и напоминаний и так нет."
        return "Отменила: " + ", ".join(x["text"] or "таймер" for x in gone) + "."
    return None
