"""
NOVA 3.0 — персональный ИИ-ассистент на Gemini с современным интерфейсом.

Запуск: ярлык «NOVA» на рабочем столе (или  py nova.pyw  в этой папке).
Окно открывается через Microsoft Edge в режиме приложения — без вкладок и адресной строки,
выглядит как обычная программа. Если Edge нет — откроется браузер по умолчанию.

Как устроено:
  • nova.pyw     — этот файл: маленький локальный сервер (только для этого компьютера) и запуск окна;
  • nova_core.py — «мозг»: Gemini, поиск в интернете, история чатов, команды;
  • ui/          — интерфейс: index.html, style.css, app.js, markdown.js;
  • chats/       — сохранённые чаты; nova_errors.log — журнал ошибок.
Старое окно на tkinter осталось в nova_classic.pyw.

Когда окно закрывают, сервер сам выключается через несколько секунд.
"""

import argparse
import base64
import json
import mimetypes
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nova_core as core  # noqa: E402

UI_DIR = os.path.join(core.APP_DIR, "ui")
PORTS = range(47313, 47323)
TOKEN = secrets.token_urlsafe(24)  # без него сервер не отвечает — чужие сайты не смогут им пользоваться
PORT = None
APP = None

STATIC = {
    "/style.css": (os.path.join(UI_DIR, "style.css"), "text/css; charset=utf-8"),
    "/app.js": (os.path.join(UI_DIR, "app.js"), "text/javascript; charset=utf-8"),
    "/markdown.js": (os.path.join(UI_DIR, "markdown.js"), "text/javascript; charset=utf-8"),
    "/favicon.ico": (os.path.join(core.APP_DIR, "nova.ico"), "image/x-icon"),
}


def show_fatal(text):
    """Если NOVA не может запуститься — показать окошко с причиной, а не молча исчезнуть."""
    core.log_error(text)
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror("NOVA", f"NOVA не смогла запуститься:\n\n{text[-600:]}\n\nПодробности: {core.LOG_FILE}")
        r.destroy()
    except Exception:
        pass


# =========================
# СОСТОЯНИЕ ПРОГРАММЫ
# =========================

class App:
    def __init__(self):
        self.settings = core.load_settings()
        self.brain = core.NovaBrain(self.settings)  # общий словарь: настройки сразу видны «мозгу»
        self.chats = core.load_chats()
        self.current = core.make_chat()
        self.lock = threading.RLock()
        self.busy = False
        self.started = time.time()
        self.last_ping = None
        self.bye_at = None
        self.exported = set()  # файлы, сохранённые в «Загрузки», — только их можно «показать в папке»

    @staticmethod
    def summary(chat):
        return {"id": chat["id"], "title": chat["title"], "updated": chat["updated"],
                "count": len(chat["messages"]), "role": bool(chat.get("role"))}

    def find_chat(self, chat_id):
        if self.current["id"] == chat_id:
            return self.current
        return self.chats.get(chat_id)

    def state(self):
        with self.lock:
            chats = sorted(self.chats.values(), key=lambda c: c.get("updated", ""), reverse=True)
            return {
                "ready": self.brain.ready,
                "problem": self.brain.problem,
                "mode": self.brain.mode,
                "modes": {
                    k: {"title": v["title"], "kind": v["kind"], "hint": v["hint"], "engine": v["engine"],
                        "group": v.get("group", ""), "available": ok, "problem": why, "sees": core.can_see(k)}
                    for k, v in core.MODES.items() for ok, why in [self.brain.status(k)]
                },
                "groups": core.GROUPS,
                "settings": self.settings,
                "key": core.key_info(),
                "dskey": core.ds_key_info(),
                "personas": {k: {"title": v["title"], "desc": v["desc"]} for k, v in core.PERSONAS.items()},
                "model": self.brain.model if self.brain.ready else None,
                "busy": self.busy,
                "timers": core.timers.upcoming(),
                "now": time.time(),
                "current": self.current,
                "chats": [self.summary(c) for c in chats],
            }

    def record(self, chat, role, text, sources=None, local=False, stopped=False, files=None, note="", actions=None,
               remembered=None):
        """Добавить сообщение в чат и сразу сохранить на диск."""
        with self.lock:
            stamp = core.datetime.now().isoformat(timespec="seconds")
            msg = {"role": role, "text": text, "time": stamp}
            if remembered:  # что NOVA запомнила в долгую память во время этого ответа
                msg["remembered"] = remembered
            if files:
                msg["files"] = files
            if actions:  # кнопки подтверждения под ответом («Закрыть Roblox»)
                msg["actions"] = [dict(a, state="pending") for a in actions]
            if sources:
                msg["sources"] = [list(s) for s in sources]
            if note:
                msg["note"] = note  # «Symphony недоступна — ответила Sonata»
            if local:
                msg["local"] = True
            if stopped:
                msg["stopped"] = True
            if not chat["messages"]:
                chat["title"] = core.make_title(text, files)
            chat["messages"].append(msg)
            chat["updated"] = stamp
            self.chats[chat["id"]] = chat
            core.save_chat(chat)

    def mark_action(self, aid, state, result):
        """Запомнить в чате, чем кончилась кнопка подтверждения (сделано / отменено / устарела)."""
        with self.lock:
            for chat in self.chats.values():
                for msg in chat.get("messages", []):
                    for a in msg.get("actions") or []:
                        if a.get("id") == aid:
                            a.update(state=state, result=result)
                            core.save_chat(chat)
                            return

    def auto_title(self, chat, question, answer):
        """В фоне придумать чату короткое название (если его не переименовали вручную)."""
        title = self.brain.suggest_title(question, answer)
        if not title:
            return
        with self.lock:
            first = chat["messages"][0] if chat["messages"] else None
            if first and chat["title"] == core.make_title(first["text"], first.get("files")):
                chat["title"] = title
                core.save_chat(chat)

    def search(self, query):
        q = query.lower().strip()
        found = []
        with self.lock:
            for chat in sorted(self.chats.values(), key=lambda c: c.get("updated", ""), reverse=True):
                snippet = ""
                if q in chat["title"].lower():
                    snippet = chat["title"]
                else:
                    for m in chat["messages"]:
                        names = " ".join(f["name"] for f in m.get("files") or [])
                        if names and q in names.lower():
                            snippet = "📎 " + names
                            break
                        pos = m["text"].lower().find(q)
                        if pos >= 0:
                            start = max(0, pos - 30)
                            snippet = ("…" if start else "") + m["text"][start:pos + 60].replace("\n", " ") + "…"
                            break
                if snippet:
                    found.append({**self.summary(chat), "snippet": snippet})
        return found[:50]


# =========================
# СЕРВЕР
# =========================

class Server(ThreadingHTTPServer):
    allow_reuse_address = False  # на Windows иначе два сервера могут занять один порт
    daemon_threads = True

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class Handler(BaseHTTPRequestHandler):
    server_version = "NOVA"

    def log_message(self, *args):
        pass  # без консольного шума

    # --- помощники ---

    def _host_ok(self):
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def _token_ok(self, allow_query=False):
        token = self.headers.get("X-Nova-Token")
        if not token and allow_query:
            token = parse_qs(urlparse(self.path).query).get("token", [None])[0]
        return token is not None and secrets.compare_digest(token, TOKEN)

    def _send(self, status, body, ctype):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > 40_000_000:  # с вложениями (base64) — до ~28 МБ файлов
            raise ValueError("слишком большой запрос")
        data = json.loads(self.rfile.read(length) or b"{}")
        return data if isinstance(data, dict) else {}

    # --- GET ---

    def do_GET(self):
        if not self._host_ok():
            return self.send_error(403)
        url = urlparse(self.path)
        path = url.path

        if path == "/hello":  # «NOVA уже запущена?» — без данных
            return self._json({"app": "nova"})
        if path in ("/", "/index.html"):
            with open(os.path.join(UI_DIR, "index.html"), encoding="utf-8") as f:
                page = f.read().replace("__NOVA_TOKEN__", TOKEN)
            return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8")
        if path in STATIC:
            file, ctype = STATIC[path]
            try:
                with open(file, "rb") as f:
                    return self._send(200, f.read(), ctype)
            except OSError:
                return self.send_error(404)
        if path.startswith("/file/"):  # вложения из чатов (картинки в переписке); токен — в адресе
            if not self._token_ok(allow_query=True):
                return self.send_error(403)
            try:
                file = core.attachment_path(unquote(path[len("/file/"):]))  # русские имена приходят закодированными
                with open(file, "rb") as f:
                    data = f.read()
            except (OSError, ValueError):
                return self.send_error(404)
            ctype = mimetypes.guess_type(file)[0] or "application/octet-stream"
            if not ctype.startswith("image/"):
                ctype = "application/octet-stream"  # в окне показываем только картинки
            return self._send(200, data, ctype)

        if not path.startswith("/api/"):
            return self.send_error(404)
        if not self._token_ok():
            return self.send_error(403)
        query = parse_qs(url.query)
        try:
            if path == "/api/state":
                return self._json(APP.state())
            if path == "/api/search":
                return self._json({"results": APP.search(query.get("q", [""])[0])})
            if path == "/api/memory":  # долгая память — для настроек
                return self._json({"facts": core.memory.facts(), "enabled": APP.settings.get("memory", True)})
        except Exception:
            core.log_error(traceback.format_exc())
            return self._json({"error": "внутренняя ошибка"}, 500)
        return self.send_error(404)

    # --- POST ---

    def do_POST(self):
        if not self._host_ok():
            return self.send_error(403)
        path = urlparse(self.path).path

        if path == "/api/bye":  # окно закрывают (sendBeacon не умеет заголовки — токен в адресе)
            if self._token_ok(allow_query=True):
                APP.bye_at = time.time() + 6
            return self._json({"ok": True})
        if not path.startswith("/api/") or not self._token_ok():
            return self.send_error(403)

        try:
            data = self._body()
            if path == "/api/ping":
                APP.last_ping, APP.bye_at = time.time(), None
                return self._json({"ok": True})
            if path == "/api/memory_delete":  # крестик у факта в настройках или «Забыть всё»
                core.memory.remove(str(data.get("id") or "")[:20] if not data.get("all") else "всё")
                return self._json({"facts": core.memory.facts()})
            if path == "/api/timer_cancel":  # крестик у таймера в шапке окна
                gone = core.timers.cancel(str(data.get("id") or "")[:20] or "-")
                return self._json({"ok": bool(gone), "timers": core.timers.upcoming()})
            if path == "/api/action":  # нажали кнопку под ответом: «Закрыть Roblox» / «Не надо»
                aid, yes = str(data.get("id") or "")[:40], bool(data.get("yes"))
                ok, result = core.pc.confirm(aid, yes)
                APP.mark_action(aid, ("done" if yes else "declined") if ok else "failed", result)
                return self._json({"ok": ok, "text": result})
            if path == "/api/send":
                if APP.busy:
                    return self._json({"error": "NOVA ещё отвечает"}, 409)
                text = str(data.get("text", "")).strip()[:20000]
                try:
                    files = self._take_attachments(data.get("attachments") or [])
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
                if not text and not files:
                    return self._json({"error": "пустое сообщение"}, 400)
                once = str(data.get("once") or "")  # «спросить Symphony только про это сообщение»
                return self._stream_answer(text, files, once if once in core.MODES else None, bool(data.get("voice")))
            if path == "/api/regenerate":
                return self._regenerate()
            if APP.busy and path in ("/api/new", "/api/open", "/api/delete", "/api/mode", "/api/delete_all", "/api/import"):
                return self._json({"error": "NOVA ещё отвечает"}, 409)
            if path == "/api/settings":
                with APP.lock:
                    new = core.clean_settings({**APP.settings, **data})
                    mode_changed = new["mode"] != APP.settings["mode"]
                    APP.settings.update(new)  # тот же словарь, что у «мозга»
                    core.save_settings(APP.settings)
                if mode_changed:
                    APP.brain.set_mode(new["mode"])
                return self._json(APP.state())
            if path == "/api/delete_all":
                with APP.lock:
                    for chat_id in list(APP.chats):
                        core.delete_chat_file(chat_id)
                    APP.chats.clear()
                    APP.current = core.make_chat()
                APP.brain.reset()
                return self._json(APP.state())
            if path == "/api/api_key":  # вставили ключ Gemini в настройках: проверить и сохранить
                if APP.busy:
                    return self._json({"error": "NOVA ещё отвечает — попробуй через секунду"}, 409)
                key = "".join(str(data.get("key", "")).split())
                if not 20 <= len(key) <= 200:
                    return self._json({"error": "Это не похоже на ключ Gemini — скопируй его целиком."}, 400)
                ok, message = APP.brain.check_key(key)
                if not ok:
                    return self._json({"error": message}, 400)
                core.save_api_key(key)
                APP.brain.connect(key)
                return self._json({**APP.state(), "message": message})
            if path == "/api/deepseek_key":  # ключ для Sonata (GigaChat, DeepSeek или OpenRouter): проверить и сохранить
                if APP.busy:
                    return self._json({"error": "NOVA ещё отвечает — попробуй через секунду"}, 409)
                key = "".join(str(data.get("key", "")).split())
                if not key.startswith("sk-"):
                    key = core.giga_key(key) or key
                if not 20 <= len(key) <= 200 or not (key.startswith("sk-") or core.giga_key(key)):
                    return self._json({"error": "Это не похоже на ключ GigaChat (длинная строка, часто кончается на «==») "
                                                "или DeepSeek / OpenRouter («sk-…»). Скопируй его целиком."}, 400)
                ok, message = APP.brain.check_ds_key(key)
                if not ok:
                    return self._json({"error": message}, 400)
                core.save_ds_key(key)
                return self._json({**APP.state(), "message": message})
            if path == "/api/export":  # сохранить чат в «Загрузки» (.md или .json)
                chat = APP.find_chat(str(data.get("id", "")))
                if not chat or not chat["messages"]:
                    return self._json({"error": "в этом чате пока нечего сохранять"}, 404)
                fmt = "json" if data.get("format") == "json" else "md"
                with APP.lock:
                    file = core.save_export(chat, fmt)
                APP.exported.add(file)
                return self._json({"ok": True, "path": file, "name": os.path.basename(file)})
            if path == "/api/reveal":  # показать сохранённый файл в Проводнике
                file = str(data.get("path", ""))
                if file not in APP.exported or not os.path.exists(file):
                    return self._json({"error": "файл не найден"}, 404)
                subprocess.Popen(["explorer", "/select,", file])
                return self._json({"ok": True})
            if path == "/api/import":
                try:
                    chat = core.import_chat(data.get("data"))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
                with APP.lock:
                    APP.chats[chat["id"]] = chat
                    APP.current = chat
                APP.brain.load_history(chat["messages"])
                return self._json(APP.state())
            if path == "/api/chat_role":  # роль NOVA только для этого чата
                chat = APP.find_chat(str(data.get("id", "")))
                if not chat:
                    return self._json({"error": "чат не найден"}, 404)
                role = str(data.get("role", "")).strip()[:core.ROLE_LIMIT]
                with APP.lock:
                    if role:
                        chat["role"] = role
                    else:
                        chat.pop("role", None)
                    core.save_chat(chat)  # пустой (новый) чат сохранится вместе с первым сообщением
                return self._json(APP.state())
            if path == "/api/open_file":  # открыть вложение в программе Windows по умолчанию
                try:
                    os.startfile(core.attachment_path(str(data.get("stored", ""))))
                    return self._json({"ok": True})
                except (OSError, ValueError):
                    return self._json({"error": "файл не найден"}, 404)
            if path == "/api/new":
                with APP.lock:
                    APP.current = core.make_chat()
                APP.brain.reset()
                return self._json(APP.state())
            if path == "/api/open":
                chat = APP.chats.get(data.get("id"))
                if not chat:
                    return self._json({"error": "чат не найден"}, 404)
                with APP.lock:
                    APP.current = chat
                APP.brain.load_history(chat["messages"])
                return self._json(APP.state())
            if path == "/api/delete":
                chat_id = data.get("id")
                with APP.lock:
                    if chat_id in APP.chats:
                        core.delete_chat_file(chat_id)
                        APP.chats.pop(chat_id, None)
                    deleted_current = APP.current["id"] == chat_id
                    if deleted_current:
                        APP.current = core.make_chat()
                if deleted_current:
                    APP.brain.reset()
                return self._json(APP.state())
            if path == "/api/rename":
                chat = APP.chats.get(data.get("id"))
                title = " ".join(str(data.get("title", "")).split())[:80]
                if chat and title:
                    with APP.lock:
                        chat["title"] = title
                        core.save_chat(chat)
                return self._json(APP.state())
            if path == "/api/mode":
                mode = data.get("mode")
                if mode in core.MODES:
                    APP.brain.set_mode(mode)  # меняет и APP.settings — это один словарь
                    core.save_settings(APP.settings)
                return self._json(APP.state())
            if path == "/api/open_url":
                url = str(data.get("url", ""))
                ok = url.startswith(("http://", "https://")) and core.open_url(url)
                return self._json({"ok": bool(ok)})
        except Exception:
            core.log_error(traceback.format_exc())
            return self._json({"error": "внутренняя ошибка"}, 500)
        return self.send_error(404)

    # --- вложения ---

    def _take_attachments(self, items):
        """Проверить и сохранить присланные файлы. Возвращает список описаний для чата."""
        if not isinstance(items, list):
            raise ValueError("неверные вложения")
        if len(items) > core.MAX_FILES:
            raise ValueError(f"Можно прикрепить не больше {core.MAX_FILES} файлов за раз.")
        decoded, total = [], 0
        for item in items:
            name = str(item.get("name") or "файл")[:120]
            data = base64.b64decode(str(item.get("data") or ""), validate=False)
            total += len(data)
            if total > core.MAX_TOTAL_BYTES:
                raise ValueError("Вложения слишком большие: вместе не больше 18 МБ.")
            kind, mime = core.classify_attachment(name, str(item.get("mime") or ""), data)
            decoded.append((name, kind, mime, data))
        files = []
        for name, kind, mime, data in decoded:
            stored = core.store_attachment(APP.current["id"], name, data)
            files.append({"name": name, "kind": kind, "mime": mime, "stored": stored, "size": len(data)})
        return files

    # --- ответ кусочками ---

    def _regenerate(self):
        with APP.lock:
            if APP.busy:
                return self._json({"error": "NOVA ещё отвечает"}, 409)
            messages = APP.current["messages"]
            idx = next((i for i in range(len(messages) - 1, -1, -1)
                        if messages[i]["role"] == "user" and not messages[i].get("local")), None)
            if idx is None:
                return self._json({"error": "нечего повторять"}, 400)
            text = messages[idx]["text"]
            files = messages[idx].get("files") or []
            del messages[idx:]
        APP.brain.load_history(APP.current["messages"])
        return self._stream_answer(text, files)

    def _stream_answer(self, text, files=None, once=None, voice=False):
        """Отвечает строками JSON: chat → status… → delta… → done. Окно читает их по мере прихода."""
        with APP.lock:
            if APP.busy:
                return self._json({"error": "NOVA ещё отвечает"}, 409)
            APP.busy = True
        chat = APP.current
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()

            def emit(obj):
                try:
                    self.wfile.write((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
                    self.wfile.flush()
                except OSError:
                    raise core.ClientGone()

            core.pc.begin_answer()
            core.memory.begin_answer()
            shot = False
            if not files and core.pc.wants_screenshot(text):  # «посмотри на мой экран» — приложить скриншот
                emit({"t": "status", "text": "Делаю скриншот экрана"})
                try:
                    data, mime = core.pc.screenshot()
                    name = "Скриншот экрана." + ("png" if mime == "image/png" else "jpg")
                    files = [{"name": name, "kind": "image", "mime": mime, "size": len(data),
                              "stored": core.store_attachment(chat["id"], name, data)}]
                    shot = True
                except Exception as e:
                    core.log_error(f"screenshot: {e!r}")
                    emit({"t": "status", "text": "Скриншот не получился — отвечаю без него"})

            command = None if files else core.handle_command(text)
            APP.record(chat, "user", text, local=bool(command), files=files)
            emit({"t": "chat", "chat": APP.summary(chat)})
            if shot:
                emit({"t": "attach", "files": files})  # окно покажет скриншот в сообщении пользователя
            if command:
                actions = core.pc.take_fresh()
                APP.record(chat, "ai", command, local=True, actions=actions)
                emit({"t": "done", "kind": "command", "text": command, "sources": [], "actions": actions,
                      "chat": APP.summary(chat)})
                core.memory.take_fresh()  # «запомни, что…» — ответ и так это показывает
                return

            if files:
                emit({"t": "status", "text": "Изучаю " + ("картинку" if all(f["kind"] == "image" for f in files)
                                                         and len(files) == 1 else "вложения")})
            core.set_progress(lambda s: emit({"t": "status", "text": s}))
            core.set_voice(voice)  # голосовой разговор — отвечать коротко, без списков
            try:
                answer, kind, sources = APP.brain.ask_stream(
                    text, lambda k, d: emit({"t": k, "text": d}), files, role=chat.get("role"), once=once)
            finally:
                core.set_progress(None)
                core.set_voice(False)
            note = APP.brain.last_note
            actions = core.pc.take_fresh() if kind in ("ai", "stopped") and answer else []
            if kind == "ai":
                core.memory.auto_from(text)  # модель не запомнила имя/возраст/город — NOVA сама
            remembered = core.memory.take_fresh()
            if kind in ("ai", "stopped") and answer:
                APP.record(chat, "ai", answer, sources=sources, stopped=kind == "stopped", note=note, actions=actions,
                           remembered=remembered)
                answers = sum(1 for m in chat["messages"] if m["role"] == "ai" and not m.get("local"))
                if kind == "ai" and answers == 1:  # первый настоящий ответ — придумать название чату
                    question = text or "вложения: " + ", ".join(f["name"] for f in files or [])
                    threading.Thread(target=APP.auto_title, args=(chat, question, answer), daemon=True).start()
            emit({"t": "done", "kind": kind, "text": answer, "sources": sources, "note": note, "actions": actions,
                  "remembered": remembered,
                  "model": APP.brain.model, "by": APP.brain.last_model if kind == "ai" else None,
                  "chat": APP.summary(chat)})
        except core.ClientGone:
            pass
        except Exception as e:
            core.log_error(traceback.format_exc())
            try:
                emit({"t": "done", "kind": "error", "text": f"Что-то пошло не так: {e}", "sources": []})
            except Exception:
                pass
        finally:
            APP.busy = False


# =========================
# ЗАПУСК
# =========================

def find_edge():
    candidates = [
        os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"), r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), r"Microsoft\Edge\Application\msedge.exe"),
    ]
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe") as k:
            candidates.insert(0, winreg.QueryValue(k, None))
    except OSError:
        pass
    return next((p for p in candidates if p and os.path.exists(p)), None)


def open_window(port):
    url = f"http://127.0.0.1:{port}/"
    edge = find_edge()
    if edge:
        profile = os.path.join(os.environ.get("LOCALAPPDATA", core.APP_DIR), "NOVA", "edge-profile")
        try:
            subprocess.Popen(
                [edge, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1280,840",
                 "--no-first-run", "--no-default-browser-check"],
                creationflags=getattr(subprocess, "DETACHED_PROCESS", 0),
            )
            return
        except OSError:
            core.log_error(traceback.format_exc())
    webbrowser.open(url)


def nova_running(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/hello", timeout=0.7) as r:
            return json.load(r).get("app") == "nova"
    except Exception:
        return False


def watchdog(server):
    """Выключить сервер, когда окно закрыли (или оно так и не открылось)."""
    while True:
        time.sleep(2)
        now = time.time()
        if APP.busy or core.timers.has_pending():
            continue  # окно закрыли, но таймер ещё тикает — дождаться его и только потом выключиться
        if APP.bye_at and now > APP.bye_at:
            break
        if APP.last_ping is None:
            if now - APP.started > 120:
                break
        elif now - APP.last_ping > 150:  # свёрнутое окно «пингует» реже — даём запас
            break
    server.shutdown()


def main():
    global PORT, APP
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", help="где хранить чаты и настройки (по умолчанию — папка NOVA)")
    parser.add_argument("--port", type=int)
    parser.add_argument("--no-window", action="store_true", help="не открывать окно (для проверок)")
    parser.add_argument("--export-dir", help="куда сохранять «Скачать чат» вместо «Загрузок» (для проверок)")
    args = parser.parse_args()
    if args.data_dir:
        core.set_data_dir(args.data_dir)
    if args.export_dir:
        core.set_export_dir(args.export_dir)
    core.timers.start(core.DATA_DIR)  # таймеры и напоминания (в том числе пропущенные, пока NOVA была закрыта)
    core.memory.start(core.DATA_DIR, enabled=lambda: APP is None or APP.settings.get("memory", True))

    ports = [args.port] if args.port else list(PORTS)
    if not args.no_window and not args.port:
        for port in ports:
            if nova_running(port):  # NOVA уже работает — просто открыть ещё одно окно
                open_window(port)
                return

    server = None
    for port in ports:
        try:
            server = Server(("127.0.0.1", port), Handler)
            PORT = port
            break
        except OSError:
            continue
    if server is None:
        show_fatal("Не нашлось свободного порта для окна NOVA (47313–47322).")
        return

    APP = App()
    threading.Thread(target=watchdog, args=(server,), daemon=True).start()
    if not args.no_window:
        open_window(PORT)
    server.serve_forever()
    try:
        core.giga_cleanup()  # картинки и PDF, которые смотрела Sonata, — убрать из хранилища Сбера
    except Exception as e:
        core.log_error(f"giga_cleanup: {e!r}")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        show_fatal(traceback.format_exc())
