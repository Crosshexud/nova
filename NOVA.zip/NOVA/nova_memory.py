"""NOVA — долгая память: что NOVA знает о пользователе из прошлых разговоров.

Факты лежат в nova_memory.json и попадают в подсказку для любой модели во всех чатах. Модель сама решает,
что запомнить (инструмент remember), пользователь может сказать «запомни, что…» / «забудь…» и посмотреть
или удалить всё в настройках. Секреты (пароли, карты, коды) не запоминаются.
"""

import difflib
import json
import os
import re
import threading
import time
import uuid

_state = {"dir": os.path.dirname(os.path.abspath(__file__)), "enabled": lambda: True}
_lock = threading.Lock()
_facts = []    # [{"id", "text", "at"}]
_fresh = []    # что запомнила во время текущего ответа — окно покажет под ответом
MAX_FACTS = 80
PROMPT_LIMIT = 3500  # символов в подсказке, новые важнее старых

SECRET_RE = re.compile(r"парол|password|\bpin\b|пин[- ]?код|cvv|cvc|номер карт|карт[аы]\s*\d|\b\d{4}[ -]?\d{4}[ -]?\d{4}|"
                       r"код из смс|ключ api|api key|\bтокен|\btoken|sk-[a-z0-9]", re.I)


def log(text):  # nova_core подставит свой журнал ошибок
    pass


def _file():
    return os.path.join(_state["dir"], "nova_memory.json")


def start(data_dir=None, enabled=None):
    if data_dir:
        _state["dir"] = data_dir
    if enabled:
        _state["enabled"] = enabled
    with _lock:
        _facts.clear()
        try:
            with open(_file(), encoding="utf-8") as f:
                _facts.extend(x for x in json.load(f) if isinstance(x, dict) and x.get("text"))
        except (OSError, ValueError):
            pass


def _save():
    try:
        with open(_file(), "w", encoding="utf-8") as f:
            json.dump(_facts, f, ensure_ascii=False, indent=1)
    except OSError as e:
        log(f"memory save: {e!r}")


def _norm(s):
    return " ".join(re.sub(r"[^\w\s]", " ", str(s).lower().replace("ё", "е")).split())


def facts():
    with _lock:
        return [dict(x) for x in _facts]


def split_fact(text):
    """«Тимуру 20 лет, учится на программиста, любит Minecraft» → три факта (чтобы потом забыть что-то одно).
    Режем только явный перечень из 3+ частей по 2+ слова; «Любит пиццу, суши и бургеры» не трогаем."""
    text = " ".join(str(text or "").split()).strip(" .")
    if text.startswith("Со слов пользователя"):
        return [text]
    parts = [p.strip(" .") for p in re.split(r";\s+|,\s+(?![^«]*»)", text)]
    if len(parts) >= 3 and all(len(p.split()) >= 2 for p in parts):
        return [p[:1].upper() + p[1:] for p in parts]
    return [text]


def add(text):
    """Запомнить. Возвращает (факт, что случилось: "new" / "updated" / "same") или (None, причина)."""
    text = " ".join(str(text or "").split()).strip(" .")[:300]
    if len(text) < 3:
        return None, "пусто"
    if SECRET_RE.search(text):
        return None, "секрет"
    text = text[:1].upper() + text[1:]
    n = _norm(text)
    with _lock:
        for x in _facts:
            r = difflib.SequenceMatcher(None, n, _norm(x["text"])).ratio()
            if r > 0.92:
                return dict(x), "same"
            if r > 0.72:  # почти то же самое — обновить формулировку
                x.update(text=text, at=round(time.time()))
                _save()
                return dict(x), "updated"
        item = {"id": uuid.uuid4().hex[:10], "text": text, "at": round(time.time())}
        _facts.append(item)
        del _facts[:-MAX_FACTS]
        _save()
        return dict(item), "new"


SPECIAL = {  # что пользователь называет одним словом, а в факте записано иначе
    "возраст": r"\b\d{1,3} (лет|год)|возраст", "сколько мне лет": r"\b\d{1,3} (лет|год)|возраст",
    "мой возраст": r"\b\d{1,3} (лет|год)|возраст", "имя": r"зовут|\bимя\b", "как меня зовут": r"зовут|\bимя\b",
    "мое имя": r"зовут|\bимя\b", "меня зовут": r"зовут|\bимя\b",
}


def remove(query):
    """Забыть: по номеру факта, по части текста или всё («всё»). Возвращает забытые."""
    q = str(query or "").strip()
    with _lock:
        if _norm(q) in ("все", "всё", "all", "вс", "все факты", "все обо мне", "всю память"):
            gone = list(_facts)
        elif any(x["id"] == q for x in _facts):
            gone = [x for x in _facts if x["id"] == q]
        else:
            nq = re.sub(r"^(про|о|об|что|как)\s+", "", _norm(q))
            special = next((rx for word, rx in SPECIAL.items() if nq.startswith(word)), None)
            if special:  # «забудь про возраст» → факт с «20 лет»
                gone = [x for x in _facts if re.search(special, _norm(x["text"]))]
            else:
                stems = [w[:max(4, len(w) - 2)] for w in re.findall(r"\w{3,}", nq)]
                gone = [x for x in _facts if stems and all(st in _norm(x["text"]) for st in stems)]
            if not gone and q:
                best = max(_facts, key=lambda x: difflib.SequenceMatcher(None, _norm(q), _norm(x["text"])).ratio(),
                           default=None)
                if best and difflib.SequenceMatcher(None, _norm(q), _norm(best["text"])).ratio() > 0.6:
                    gone = [best]
        for x in gone:
            _facts.remove(x)
        if gone:
            _save()
        return gone


def prompt_block():
    """Кусок подсказки для модели или "" (память пуста или выключена)."""
    if not _state["enabled"]():
        return ""
    with _lock:
        items = sorted(_facts, key=lambda x: x.get("at", 0), reverse=True)
    lines, size = [], 0
    for x in items:
        if size + len(x["text"]) > PROMPT_LIMIT:
            break
        lines.append("- " + x["text"])
        size += len(x["text"]) + 3
    if not lines:
        return ""
    return ("ДОЛГАЯ ПАМЯТЬ — что ты знаешь о пользователе из прошлых разговоров. Используй, когда это к месту "
            "(подстраивай советы и примеры), но не пересказывай без повода и не говори «я помню из памяти» в каждом "
            "ответе:\n" + "\n".join(reversed(lines)))


RULES = (
    "У тебя есть долгая память о пользователе (инструменты remember и forget). Когда пользователь рассказывает о себе "
    "что-то устойчивое и важное — имя, возраст, учёба или работа, город, друзья и родные, питомцы, увлечения, любимые "
    "игры и музыка, свои проекты, цели, как ему удобнее получать ответы — вызови remember с коротким фактом от третьего "
    "лица. Один вызов — одна мысль: имя, возраст, учёба и увлечения — отдельными фактами, чтобы потом можно было "
    "забыть что-то одно. Если просит «запомни» — тоже remember. Не запоминай разовое (погода, один вопрос), чужие тайны "
    "и секреты (пароли, номера карт, коды). Если факт устарел или просят забыть — forget только этот факт, остальные "
    "не трогай. Отвечай как обычно; NOVA сама покажет под ответом, что запомнила."
)


def begin_answer():
    _fresh.clear()


# Подстраховка для моделей, которые не вызывают remember (например, облегчённые Gemini):
# самое однозначное NOVA замечает сама — имя, возраст, город.
NOT_NAMES = {"так", "как", "просто", "все", "всё", "никак", "по", "тоже", "также", "иначе", "вроде", "типа"}
AUTO_RULES = [
    (re.compile(r"(?i)\bменя\s+зовут\s+([а-яёa-z]{2,15})(?=[\s,.!?)]|$)"), "Пользователя зовут {}"),
    (re.compile(r"(?i)\bмне\s+(\d{1,2})\s+(?:год|года|лет)\b"), "Возраст пользователя: {}"),
    (re.compile(r"(?i)\bя\s+(?:сейчас\s+)?живу\s+в\s+([а-яёa-z-]{3,20})(?=[\s,.!?)]|$)"), "Живёт в городе {}"),
]


def auto_from(text):
    """Если модель ничего не запомнила — поймать имя, возраст и город из сообщения пользователя."""
    if not _state["enabled"]() or _fresh:
        return
    for rx, fmt in AUTO_RULES:
        m = rx.search(str(text or ""))
        if not m or m.group(1).lower() in NOT_NAMES:
            continue
        value = m.group(1)
        item, how = add(fmt.format(value[:1].upper() + value[1:]))
        if item and how != "same":
            _fresh.append(item["text"])


def take_fresh():
    out = list(_fresh)
    _fresh.clear()
    return out


# =========================
# Инструменты для нейросетей
# =========================

def remember(fact: str) -> dict:
    """Запомнить надолго важный факт о пользователе — он будет известен во всех чатах (имя, учёба, увлечения,
    проекты, друзья, предпочтения). Вызывай, когда пользователь рассказал о себе что-то устойчивое или попросил
    «запомни». Не для разовых вещей и не для секретов.

    Args:
        fact: один короткий факт (одна мысль) от третьего лица, например «Делает игры в Roblox вместе с друзьями»
    """
    if not _state["enabled"]():
        return {"error": "Долгая память выключена в настройках NOVA — не запоминаю."}
    saved = []
    for part in split_fact(fact):
        item, how = add(part)
        if not item:
            if how == "секрет":
                return {"error": "Это секрет — такое NOVA не запоминает."}
            continue
        if how != "same" and item["text"] not in _fresh:
            _fresh.append(item["text"])
        saved.append(item["text"])
    if not saved:
        return {"error": "Пустой факт."}
    return {"ok": True, "remembered": saved}


def forget(fact: str) -> dict:
    """Забыть факт о пользователе из долгой памяти (когда просит забыть или факт устарел).

    Args:
        fact: что забыть — часть текста факта или «всё»
    """
    gone = remove(fact)
    if not gone:
        return {"error": "Не нашла такого в памяти.", "memory": [x["text"] for x in facts()][:40]}
    return {"ok": True, "forgotten": [x["text"] for x in gone]}


TOOLS = [remember, forget]


# =========================
# Быстрые команды без нейросети
# =========================

def quick_command(text):
    t = " ".join(str(text or "").split()).strip()
    low = t.lower().replace("ё", "е").rstrip(" .!?")
    if low in ("что ты обо мне знаешь", "что ты обо мне помнишь", "что ты помнишь обо мне", "что ты знаешь обо мне",
               "покажи память", "твоя память", "что в памяти"):
        items = facts()
        if not items:
            return "Пока я ничего о тебе не запомнила. Расскажи о себе — или напиши «запомни, что …»."
        return "Вот что я о тебе помню:\n" + "\n".join(f"- {x['text']}" for x in items) + \
            "\n\nУдалить можно в ⚙ Настройках → «Память» или словами «забудь …»."
    m = re.fullmatch(r"(?:nova,?\s+)?запомни(?:,?\s*что)?[,:]?\s+(.{3,})", t, flags=re.I | re.S)
    if m and _state["enabled"]():
        fact = m.group(1).strip().strip("«»\"").strip()
        # слова пользователя как есть — иначе модель примет «люблю котов» / «я…» на свой счёт
        fact = f"Со слов пользователя: «{fact[:1].upper() + fact[1:]}»"
        item, how = add(fact)
        if not item:
            return "Это похоже на секрет (пароль, карта, код) — такое я не запоминаю. 🔒" if how == "секрет" else None
        _fresh.append(item["text"])
        return {"new": "Запомнила! 🧠", "updated": "Обновила в памяти! 🧠", "same": "Это я уже помню. 🧠"}[how] + \
            f"\n\n> {item['text']}"
    m = re.fullmatch(r"забудь(?:,?\s*что)?[,:]?\s+(.{2,})", t, flags=re.I | re.S)
    if m:
        gone = remove(m.group(1))
        if not gone:
            return None  # пусть разберётся нейросеть («забудь, о чём мы говорили» — не про память)
        return "Забыла: " + "; ".join(x["text"] for x in gone) + "."
    return None
