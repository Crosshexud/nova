# NOVA: creates a desktop shortcut (and optionally starts NOVA).
# Called by "Install NOVA.bat". ASCII only on purpose: Windows PowerShell 5.1 reads scripts in the ANSI code page.
param(
    [string]$Desktop = [Environment]::GetFolderPath('Desktop'),
    [switch]$Launch
)

$ErrorActionPreference = 'Stop'
$novaDir = Split-Path -Parent $PSScriptRoot
$script = Join-Path $novaDir 'nova.pyw'

# Windowless Python: pyw (Python launcher) or pythonw.
$runner = $null
foreach ($name in 'pyw', 'pythonw') {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -notmatch 'WindowsApps\\pythonw?\.exe$') { $runner = $cmd.Source; break }
}
if (-not $runner) {
    # Fallback: ask Python itself where pythonw.exe is.
    $py = Get-Command py -ErrorAction SilentlyContinue
    if (-not $py) { $py = Get-Command python -ErrorAction SilentlyContinue }
    if ($py) {
        $exe = & $py.Source -c "import sys, os; print(os.path.join(os.path.dirname(sys.executable), 'pythonw.exe'))"
        if ($exe -and (Test-Path $exe)) { $runner = $exe }
    }
}
if (-not $runner) { Write-Output 'NO_PYTHONW'; exit 2 }

$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut((Join-Path $Desktop 'NOVA.lnk'))
$lnk.TargetPath = $runner
$lnk.Arguments = '"' + $script + '"'
$lnk.WorkingDirectory = $novaDir
$lnk.IconLocation = (Join-Path $novaDir 'nova.ico') + ',0'
$lnk.Description = 'NOVA AI assistant'
$lnk.Save()
Write-Output ('SHORTCUT_OK ' + $runner)

if ($Launch) { Start-Process -FilePath $runner -ArgumentList ('"' + $script + '"') -WorkingDirectory $novaDir }
