"""
Плашка фонового помощника NOVA: справа внизу, поверх всех окон, не забирает фокус (игре не мешает).
Запускает nova_voice.py и шлёт строки JSON в stdin:
  {"show": true, "state": "awake", "title": "Слушаю…", "text": "открой дискорд"}
  {"hide": true, "delay": 2.5}     {"quit": true}
Клик по плашке — печатает "open" (NOVA откроет своё окно).
"""

import ctypes
import json
import math
import queue
import sys
import threading
import time
import tkinter as tk

W, H = 360, 92
KEY = "#ff00fe"  # этот цвет становится прозрачным — так получаются скруглённые углы
COLORS = {"awake": "#67e8f9", "thinking": "#c4b5fd", "speaking": "#a78bfa", "confirm": "#fbbf24",
          "error": "#f87171", "idle": "#8b5cf6"}

user32 = ctypes.windll.user32
GWL_EXSTYLE = -20
WS_EX_TOPMOST, WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE = 0x8, 0x80, 0x08000000
SW_HIDE, SW_SHOWNOACTIVATE = 0, 4
HWND_TOPMOST = -1
SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE, SWP_SHOWWINDOW = 0x1, 0x2, 0x10, 0x40
user32.GetParent.restype = ctypes.c_void_p
user32.GetParent.argtypes = [ctypes.c_void_p]
user32.GetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int]
user32.SetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long]
user32.ShowWindow.argtypes = [ctypes.c_void_p, ctypes.c_int]
user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                ctypes.c_int, ctypes.c_uint]


def work_area():
    class RECT(ctypes.Structure):
        _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]
    r = RECT()
    user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA — без панели задач
    return r.l, r.t, r.r, r.b


def rounded(c, x1, y1, x2, y2, r, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2,
           x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


class Bubble:
    def __init__(self):
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.configure(bg=KEY)
        self.root.wm_attributes("-transparentcolor", KEY)
        self.root.wm_attributes("-topmost", True)
        self.root.wm_attributes("-alpha", 0.97)
        l, t, r, b = work_area()
        self.root.geometry(f"{W}x{H}+{r - W - 18}+{b - H - 18}")
        self.c = tk.Canvas(self.root, width=W, height=H, bg=KEY, highlightthickness=0, cursor="hand2")
        self.c.pack()
        self.c.bind("<Button-1>", self.click)
        self.q = queue.Queue()
        self.state, self.title, self.text = "idle", "", ""
        self.visible = False
        self.hide_at = 0.0
        self.t0 = time.time()
        self.root.update_idletasks()
        self.hwnd = user32.GetParent(self.root.winfo_id()) or self.root.winfo_id()
        ex = user32.GetWindowLongW(self.hwnd, GWL_EXSTYLE)
        user32.SetWindowLongW(self.hwnd, GWL_EXSTYLE, ex | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE)
        user32.ShowWindow(self.hwnd, SW_HIDE)
        threading.Thread(target=self.read, daemon=True).start()
        self.root.after(30, self.loop)

    def read(self):
        for line in sys.stdin:
            try:
                self.q.put(json.loads(line))
            except ValueError:
                pass
        self.q.put({"quit": True})

    def click(self, _e=None):
        print("open", flush=True)
        self.hide()

    def show(self):
        if not self.visible:
            user32.ShowWindow(self.hwnd, SW_SHOWNOACTIVATE)
            self.visible = True
        user32.SetWindowPos(self.hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE)

    def hide(self):
        if self.visible:
            user32.ShowWindow(self.hwnd, SW_HIDE)
            self.visible = False

    def loop(self):
        while not self.q.empty():
            m = self.q.get()
            if m.get("quit"):
                self.root.destroy()
                return
            if m.get("show"):
                self.state = m.get("state", "awake")
                self.title = m.get("title", "")
                self.text = m.get("text", "")
                self.hide_at = 0
                self.show()
            elif m.get("hide"):
                delay = float(m.get("delay") or 0)
                if not delay:
                    self.hide()
                elif self.visible and not self.hide_at:
                    self.hide_at = time.time() + delay
        if self.hide_at and time.time() > self.hide_at:
            self.hide_at = 0
            self.hide()
        if self.visible:
            self.draw()
        self.root.after(33, self.loop)

    def draw(self):
        c = self.c
        c.delete("all")
        col = COLORS.get(self.state, "#8b5cf6")
        t = time.time() - self.t0
        rounded(c, 2, 2, W - 2, H - 2, 22, fill="#0b0a1c", outline=col, width=2)
        cx, cy = 46, H // 2
        pulse = 1 + (0.12 * math.sin(t * 6) if self.state in ("awake", "speaking", "confirm") else 0.04 * math.sin(t * 2))
        for k, a in ((30, "#1a1535"), (24, "#221a48")):
            c.create_oval(cx - k * pulse, cy - k * pulse, cx + k * pulse, cy + k * pulse, fill=a, outline="")
        r = 16 * pulse
        c.create_oval(cx - r, cy - r, cx + r, cy + r, fill=col, outline="")
        c.create_oval(cx - r * 0.45 - 3, cy - r * 0.55 - 2, cx - r * 0.45 + 5, cy - r * 0.55 + 6, fill="#ffffff",
                      outline="")
        if self.state == "thinking":
            a = (t * 360) % 360
            c.create_arc(cx - 25, cy - 25, cx + 25, cy + 25, start=a, extent=80, style="arc", outline=col, width=3)
        c.create_text(84, 26, anchor="w", text="NOVA", fill="#ffffff", font=("Segoe UI Semibold", 10))
        c.create_text(130, 26, anchor="w", text=self.title, fill=col, font=("Segoe UI", 10))
        text = self.text if len(self.text) <= 110 else self.text[:107] + "…"
        c.create_text(84, 44, anchor="nw", text=text, fill="#d9d4ff", font=("Segoe UI", 10), width=W - 100)


if __name__ == "__main__":
    Bubble().root.mainloop()
